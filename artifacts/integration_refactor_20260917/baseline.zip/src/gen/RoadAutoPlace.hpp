﻿#pragma once
#include "../world/World.hpp"
#include "../road/RoadNetwork.hpp"

/// @brief スタート/ゴール指定による自動敷設ユーティリティ
/// @details RoadPathfinder + MapGenerator::buildRoadSegment と同じアルゴリズムを使い、
///          ゲームプレイ中にユーザが指定した 2 点間の道路を Planned 状態で敷設する。
namespace RoadAutoPlace
{
	/// @brief 初期生成と同じ地形探索から編集可能な点列を得る。
	Array<Vec3> findWaypoints(const World& world, Vec3 startWorld, Vec3 goalWorld, RoadType type = RoadType::LocalRoad);
	/// @brief 制約を満たした曲線列をそのままプレビュー・建設へ引き継ぐ。
	Array<int> buildAlignment(RoadNetwork& roads,const World& world,Array<CubicBezier> curves,
		const RoadEdge& roadTemplate,float connectionRadius=.5f);
	/// @brief 編集済み点列を再探索せず、共通の曲線生成で道路へ変換する。
	Array<int> buildWaypoints(RoadNetwork& roads, const World& world, Array<Vec3> points,
		const RoadEdge& roadTemplate, float connectionRadius = .5f);
	/// @brief 2 点間の経路探索を実行し、Planned エッジを道路ネットワークに追加する。
	/// @param roads          対象の RoadNetwork
	/// @param world          高さ計算に使用するワールド
	/// @param startWorld     スタートワールド座標
	/// @param goalWorld      ゴールワールド座標
	/// @param routeIds       新規エッジに紐付けるルート ID リスト（空可）
	/// @param templateEdge   生成エッジに適用する道路テンプレート（parts・lanes・roadType を反映）
	/// @return 追加されたエッジ ID 一覧。経路探索失敗時は空配列
	Array<int> buildPlanned(
		RoadNetwork& roads,
		const World& world,
		Vec3 startWorld, Vec3 goalWorld,
		const Array<int>& routeIds,
		const RoadEdge& templateEdge,
		bool followTerrain = true, float connectionRadius = 20.0f);

	/// @brief 複数のアンカーポイントを順に結ぶ仮計画エッジを生成する。
	Array<int> buildPreviewPlan(
		RoadNetwork& roads,
		const World& world,
		const Array<Vec3>& anchorPoints,
		const RoadEdge& templateEdge,
		bool followTerrain = true, float connectionRadius = 20.0f);
}
