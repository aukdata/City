﻿#include "Camera.hpp"
#include "KeyboardActions.hpp"

GameCamera::GameCamera()
{
	// メンバ変数はヘッダの初期値で初期化済み
	rebuild();
}

void GameCamera::update(double dt, const World& world)
{
	// カメラモードごとに入力と再構築方法を切り替え、Overview / Follow / FirstPerson を一つの状態機械で扱う。
	if (m_mode == CameraMode::Overview)
	{
		handleInput(Clamp(dt,0.0,.1), world);
		rebuild(&world);
	}
	else if (m_mode == CameraMode::Follow)
	{
		// ホイールズームで追従距離調整は不要。yaw 調整のみ許容
		if (MouseM.pressed() && !m_blockInput)
		{
			const Vec2 delta = Cursor::DeltaF();
			m_followHeading -= static_cast<float>(delta.x) * ROTATE_SPEED * 4.0f;
		}
		rebuildFollow();
		// Overview に戻ったとき focus を現在の追従位置にリセット
		m_focus = m_followPos;
	}
	else if (m_mode == CameraMode::Driving)
	{
		if (!m_blockInput && (MouseR.down() || MouseM.down())) { m_dragAnchor=Cursor::Pos(); }
		if (!m_blockInput && (MouseR.pressed() || MouseM.pressed()))
		{
			const Vec2 delta=Cursor::DeltaF();
			setDrivingLook(m_drivingLook+Vec2{delta.x,-delta.y}*.003);
			Cursor::SetPos(m_dragAnchor);
			Cursor::RequestStyle(CursorStyle::Hidden);
		}
		else
		{
			// 見回しボタンを離すと前方へ穏やかに戻す。
			m_drivingLook*=Exp(-8*Clamp(dt,0.0,.1));
		}
		rebuildDriving();
	}
	else if (m_mode == CameraMode::FirstPerson)
	{
		handleFirstPersonInput(Clamp(dt,0.0,.1), world);
	}
	else
	{
		rebuild(&world);
	}
}

void GameCamera::handleInput(double dt, const World& world)
{
	// Overview では WASD 移動、ホイールドラッグ回転、Shift パン、ホイールズームをまとめて処理する。
	// ─── WASD 移動 ─────────────────────────────────────────────────────────────
	const Vec3   forward    = Vec3{ -Math::Sin(m_yaw), 0.0, -Math::Cos(m_yaw) };
	const Vec3   right      = Vec3{  Math::Cos(m_yaw), 0.0, -Math::Sin(m_yaw) };
	const double ctrlBoost  = GameInput::pressed(KeyControl) ? 2.0 : 1.0;
	const double speedScale = static_cast<double>(MOVE_SPEED) * dt * (m_distance / 300.0) * ctrlBoost;

	Vec3 wasdDelta{ 0.0, 0.0, 0.0 };
	if (!m_keyboardBlocked && GameInput::pressed(KeyW)) wasdDelta += forward * speedScale;
	if (!m_keyboardBlocked && GameInput::pressed(KeyS)) wasdDelta -= forward * speedScale;
	if (!m_keyboardBlocked && GameInput::pressed(KeyA)) wasdDelta += right   * speedScale;
	if (!m_keyboardBlocked && GameInput::pressed(KeyD)) wasdDelta -= right   * speedScale;
	m_focus += wasdDelta;

	// ホイールドラッグ中も WASD が有効になるよう、ピボットも同量移動する
	if (MouseM.pressed() && m_hasOrbitPivot)
		m_orbitPivot += wasdDelta;

	// ─── ホイールクリックドラッグ ─────────────────────────────────────────────
	// Shift なし: 地形交点を中心に回転
	// Shift あり: カメラ平行移動（パン）
	// パネル上ではスキップ

	if (MouseM.down() && !m_blockInput)
	{
		m_dragAnchor    = Cursor::Pos();
		m_hasOrbitPivot = false;

		// Shift パン中は回転ピボット計算不要
		if (!GameInput::pressed(KeyShift))
		{
			const Ray    ray  = screenToRay(Vec2{ m_dragAnchor });
			const Float3 orig = ray.origin.xyz();
			const Float3 dir  = ray.direction.xyz();

			// 下方向成分がなければ地形に当たらない（水平・上向きレイはスキップ）
			if (dir.y < 0.0f)
			{
				const float kStep = Max(10.0f, m_distance / 800.0f);
				const float kMaxDist = Max(8000.0f, m_distance * 3.0f);
				float tPrev = 0.0f;

				for (float t = kStep; t < kMaxDist; t += kStep)
				{
					const float px = orig.x + dir.x * t;
					const float pz = orig.z + dir.z * t;
					const float py = orig.y + dir.y * t;

					if (py <= world.sampleHeight(px, pz))
					{
						const float tMid = (tPrev + t) * 0.5f;
						const float hx   = orig.x + dir.x * tMid;
						const float hz   = orig.z + dir.z * tMid;
						const float hy   = world.sampleHeight(hx, hz);

						m_orbitPivot    = Vec3{ hx, hy, hz };
						m_hasOrbitPivot = true;
						break;
					}
					tPrev = t;
				}
			}
		}
	}

	if (MouseM.pressed() && !m_blockInput)
	{
		const Vec2 delta = Cursor::DeltaF();

		if (GameInput::pressed(KeyShift))
		{
			// ─── Shift + ホイールドラッグ: パン（平行移動）────────────────────────
			// 1 ピクセルあたりのワールド移動量: focus 平面における見かけ上のスケール
			const double panScale = static_cast<double>(m_distance) / Scene::Width()
			                        * 2.0 * Math::Tan(20.0_deg);
			const Vec3 right2  = Vec3{  Math::Cos(m_yaw), 0.0, -Math::Sin(m_yaw) };
			const Vec3 fwd     = Vec3{ -Math::Sin(m_yaw), 0.0, -Math::Cos(m_yaw) };
			m_focus += right2 * delta.x * panScale;
			m_focus += fwd   * delta.y * panScale;

			if (m_hasOrbitPivot)
			{
				m_orbitPivot += right2 * delta.x * panScale;
				m_orbitPivot += fwd   * delta.y * panScale;
			}
		}
		else
		{
			// ─── ホイールドラッグ: 地形交点を中心に回転 ─────────────────────────
			m_yaw   += static_cast<float>(delta.x) * ROTATE_SPEED;
			m_pitch += static_cast<float>(delta.y) * ROTATE_SPEED;
			m_pitch  = Clamp(
				m_pitch,
				static_cast<float>(Math::ToRadians(MIN_PITCH_DEG)),
				static_cast<float>(Math::ToRadians(MAX_PITCH_DEG)));

			// ピボット P を dragAnchor の画面位置に固定する補正
			if (m_hasOrbitPivot)
			{
				rebuild(&world);  // 仮ビルド（update() でもう一度ビルドされる）

				const Ray    ray = screenToRay(Vec2{ m_dragAnchor });
				const Float3 co  = ray.origin.xyz();
				const Float3 cd  = ray.direction.xyz();

				if (Math::Abs(cd.y) > 1e-6f)
				{
					const float t = (static_cast<float>(m_orbitPivot.y) - co.y) / cd.y;
					if (t > 0.0f)
					{
						const Vec3 Q{
							static_cast<double>(co.x + cd.x * t),
							m_orbitPivot.y,
							static_cast<double>(co.z + cd.z * t)
						};
						m_focus += m_orbitPivot - Q;
					}
				}
			}
		}

		// カーソルをドラッグ開始位置に固定し、ウィンドウ外へ出るのを防ぐ
		Cursor::SetPos(m_dragAnchor);
		Cursor::RequestStyle(CursorStyle::Hidden);
	}

	// ─── ホイールズーム（Ctrl 押下中はスキップ：地形編集ブラシサイズ変更に使用）───
	const double wheel = Mouse::Wheel();
	if (wheel != 0.0 && !GameInput::pressed(KeyControl) && !m_blockInput)
	{
		zoom(wheel);
	}

	// ─── Numpad0: 真上視点リセット ───────────────────────────────────────────
	if (!m_keyboardBlocked && GameInput::down(KeyNum0))
	{
		m_pitch = static_cast<float>(Math::ToRadians(89.0));
		m_yaw   = 0.0f;
	}
}

void GameCamera::zoom(double notches)
{
	if (!IsFinite(notches)) { return; }
	m_distance = static_cast<float>(Clamp(m_distance * Pow(1.0 + ZOOM_SPEED, Clamp(notches, -200.0, 200.0)),
		static_cast<double>(MIN_DIST), static_cast<double>(MAX_DIST)));
}

void GameCamera::rebuild(const World* world)
{
	// focus, yaw, pitch, distance から俯瞰カメラを再構築し、必要なら地形へ潜らない高さまで持ち上げる。
	Vec3 eye = m_focus + Vec3{
		Math::Sin(m_yaw)  * Math::Cos(m_pitch),
		Math::Sin(m_pitch),
		Math::Cos(m_yaw)  * Math::Cos(m_pitch)
	} * m_distance;

	Vec3 target = m_focus;
	if (world)
	{
		const double terrainY = world->sampleHeight(static_cast<float>(eye.x), static_cast<float>(eye.z));
		if (m_mode == CameraMode::Overview)
		{
			// 地面からの高度を距離と俯角から決める。標高差で視線の俯角を変えない。
			const double clearance = Max<double>(MIN_HEIGHT_ABOVE_TERRAIN, Sin(m_pitch) * m_distance);
			const double lift = terrainY + clearance - eye.y;
			eye.y += lift;
			target.y += lift;
			m_focus.y = world->sampleHeight(static_cast<float>(m_focus.x), static_cast<float>(m_focus.z));
		}
		else { eye.y = Max(eye.y, terrainY + MIN_HEIGHT_ABOVE_TERRAIN); }
	}

	m_camera = BasicCamera3D{ Scene::Size(), 40_deg, eye, target };
}

void GameCamera::setFocus(Vec3 focus)
{
	m_focus = focus;
	if (m_mode == CameraMode::FirstPerson)
	{
		rebuildFirstPerson();
	}
	else
	{
		rebuild();  // 初期化用：地形床クランプなし
	}
}

void GameCamera::setState(Vec3 focus, float distance, float yaw, float pitch)
{
	m_focus    = focus;
	m_distance = distance;
	m_yaw      = yaw;
	m_pitch    = pitch;
	rebuild();
}

void GameCamera::setCaptureState(Vec3 focus, float distance, float yaw, float pitch)
{
	m_mode     = CameraMode::Capture;
	m_focus    = focus;
	m_distance = distance;
	m_yaw      = yaw;
	m_pitch    = pitch;
	rebuild();
}

Optional<Vec3> GameCamera::screenToGround(Vec2 screenPos) const
{
	const Ray ray = m_camera.screenToRay(screenPos);

	// y=0 の無限平面（通過点 = 原点, 法線 = (0,1,0)）と交差判定する
	if (const auto hit = ray.intersectsAt(InfinitePlane{ Float3{ 0, 0, 0 }, Float3{ 0, 1, 0 } }))
	{
		const Vec3 pos{ *hit };
		if (IsFinite(pos.x) && IsFinite(pos.z))
			return pos;
	}

	return none;
}

Ray GameCamera::screenToRay(Vec2 screenPos) const
{
	return m_camera.screenToRay(screenPos);
}

void GameCamera::setFollowTarget(Vec3 pos, float heading)
{
	m_followPos     = pos;
	m_followHeading = heading;
}

void GameCamera::rebuildFollow()
{
	// Follow モードでは対象の後方高めから見る固定追従カメラを組み、操作を最小限に絞る。
	// 車両の後方 25m・高さ 10m からターゲットを見る
	const Vec3 back = Vec3{
		-Math::Sin(m_followHeading),
		0.0,
		-Math::Cos(m_followHeading)
	};
	const Vec3 eye    = m_followPos + back * 25.0 + Vec3{ 0, 10, 0 };
	const Vec3 target = m_followPos + Vec3{ 0, 2, 0 };
	m_camera = BasicCamera3D{ Scene::Size(), 60_deg, eye, target };
}

void GameCamera::handleFirstPersonInput(double dt, const World& world)
{
	// マウスで視点回転
	if (MouseR.down() || MouseM.down()) { m_dragAnchor=Cursor::Pos(); }
	if (!m_blockInput && (MouseR.pressed() || MouseM.pressed()))
	{
		const Vec2 delta = Cursor::DeltaF();
		m_fpYaw   += static_cast<float>(delta.x) * 0.003f;
		m_fpPitch -= static_cast<float>(delta.y) * 0.003f;
		m_fpPitch  = Clamp(m_fpPitch,
			static_cast<float>(Math::ToRadians(-80.0)),
			static_cast<float>(Math::ToRadians(80.0)));
		Cursor::SetPos(m_dragAnchor);
		Cursor::RequestStyle(CursorStyle::Hidden);
	}

	const Vec2 input = m_keyboardBlocked ? Vec2{0,0} : Vec2{
		static_cast<double>(GameInput::pressed(KeyD))-GameInput::pressed(KeyA),
		static_cast<double>(GameInput::pressed(KeyW))-GameInput::pressed(KeyS)};
	walk(input,walkingSpeed(GameInput::pressed(KeyShift),GameInput::pressed(KeyControl))*dt,world);
}

void GameCamera::walk(Vec2 input,double distance,const World& world)
{
	const Vec3 forward{Sin(m_fpYaw),0,Cos(m_fpYaw)};
	// Siv3D uses a left-handed view: up cross forward is screen right.
	const Vec3 right=Vec3{0,1,0}.cross(forward);
	if (input.lengthSq()>1) { input.normalize(); }
	const int steps=Max(1,static_cast<int>(std::ceil(Abs(distance)/.75)));
	for (int step=0;step<steps;++step)
	{
		m_focus+=(right*input.x+forward*input.y)*(distance/steps);
		m_focus.y=m_walkSurface ? m_walkSurface(m_focus) : world.sampleHeight(static_cast<float>(m_focus.x),static_cast<float>(m_focus.z));
	}
	rebuildFirstPerson();
}

void GameCamera::setWalkingState(Vec3 ground, float yaw, float pitch)
{
	m_mode = CameraMode::FirstPerson;
	m_focus = ground;
	m_fpYaw = yaw;
	m_fpPitch = pitch;
	rebuildFirstPerson();
}

void GameCamera::rebuildFirstPerson()
{
	constexpr double kEyeHeight = 1.5;
	const Vec3 eye = m_focus + Vec3{ 0, kEyeHeight, 0 };
	const Vec3 fwd = Vec3{
		Math::Sin(m_fpYaw) * Math::Cos(m_fpPitch),
		Math::Sin(m_fpPitch),
		Math::Cos(m_fpYaw) * Math::Cos(m_fpPitch)
	};
	const Vec3 target = eye + fwd * 10.0;
	m_camera = BasicCamera3D{ Scene::Size(), 80_deg, eye, target };
}

void GameCamera::setDrivingState(Vec3 ground,float heading,float grade)
{
	if (m_mode!=CameraMode::Driving) { m_drivingLook={0,0}; }
	m_mode=CameraMode::Driving;m_focus=ground;m_followHeading=heading;m_drivingGrade=grade;
	rebuildDriving();
}

void GameCamera::setDrivingLook(Vec2 angles)
{
	m_drivingLook={Clamp(angles.x,-110_deg,110_deg),Clamp(angles.y,-35_deg,35_deg)};
	if (m_mode==CameraMode::Driving) { rebuildDriving(); }
}

void GameCamera::rebuildDriving()
{
	constexpr double kSeatHeight=1.2,kSeatRight=.35;
	const Vec3 right{Cos(m_followHeading),0,-Sin(m_followHeading)};
	const Vec3 eye=m_focus+right*kSeatRight+Vec3{0,kSeatHeight,0};
	const double heading=m_followHeading+m_drivingLook.x,pitch=m_drivingGrade+m_drivingLook.y;
	const Vec3 forward{Sin(heading)*Cos(pitch),Sin(pitch),Cos(heading)*Cos(pitch)};
	m_camera=BasicCamera3D{Scene::Size(),80_deg,eye,eye+forward*10};
}
