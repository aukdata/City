﻿#include "GameScene.hpp"
#include "../ui/ZonePalette.hpp"
#include "../gen/SettlementDevelopment.hpp"
#include "../world/ZoneGrid.hpp"
#include "../gen/WaterCrossings.hpp"
#include "../gen/RoadTerrainFit.hpp"
#include "../gen/RoadDesignLimits.hpp"
#include "../gen/RoadVerticalAlignment.hpp"
#include "../gen/StreetBlocks.hpp"
#include "../ui/PanelWidget.hpp"
#include "../road/JunctionGeometry.hpp"
#include "../gen/RoadPathfinder.hpp"
#include "../gen/DistrictRoads.hpp"
#include "../save/RoadBinary.hpp"
#include "../save/GuideSignStorage.hpp"
#include "../save/SaveTransaction.hpp"
#include "../sim/SimGraph.hpp"
#include "../asset/AssetRegistrar.hpp"
#include "../road/RoadGeometry.hpp"
#include <exception>
#include <thread>

using ZoneGrid::worldToZoneCell;
using ZoneGrid::cellCenterXZ;

// =============================================================================
// 初期化
// =============================================================================

GameScene::GameScene(const InitData& init)
	: IScene{ init }
{
	m_worldRenderer.setAsyncTerrain(!getData().syncTerrain);
	constexpr double kRoadCacheBuildBudgetMs = 4.0;
	m_roadRenderer.setCacheBuildBudget(getData().syncRoads ? Math::Inf : kRoadCacheBuildBudgetMs);
	m_camera.setWalkSurface([this](Vec3 point)
	{
		return m_walkSurface.resolve(point,m_world,m_network,m_trainNetwork);
	});
	m_renderTexture = MSRenderTexture{ Scene::Size(), TextureFormat::R8G8B8A8_Unorm_SRGB, HasDepth::Yes };
	m_outlineMask   = RenderTexture{ Scene::Size(), TextureFormat::R8G8B8A8_Unorm,      HasDepth::Yes };
	m_outlinePS     = HLSL{ U"shaders/hlsl/selection_outline.hlsl", U"PS" };
	if (not m_outlinePS)
	{
		Print << U"[WARN] selection_outline.hlsl load failed";
	}
	m_trainManager.init(&m_trainNetwork);

	m_roadRenderer.loadAssets();

	m_sandboxActive = getData().sandboxMode;

	initScene();
}

GameScene::~GameScene()
{
	GameInput::releaseTextFocus();
	m_simThread.stop();

	if (m_generationFuture.valid())
		m_generationFuture.wait();
}

void GameScene::initScene()
{
	// シーン全体で使う UI パネルと、編集系の初期テンプレートをここでまとめて準備する。
	m_panelManager.registerPanel(U"edge_info", Vec2{374, static_cast<double>(Scene::Height() - 20)}, true, true);
	m_panelManager.registerPanel(U"node_info", Vec2{312, static_cast<double>(Scene::Height() - 20)}, true, true);
	m_panelManager.registerPanel(U"name_list", Vec2{250, static_cast<double>(Scene::Height() - 20)}, false, true);
	m_panelManager.registerPanel(U"vehicle_info", Vec2{280, static_cast<double>(Scene::Height() - 20)}, true, true);
	m_panelManager.registerPanel(U"land_info",Vec2{320,190},true,true);
	m_panelManager.registerPanel(U"zone_palette",Vec2{ZonePalette::kWidth,ZonePalette::kHeight+24},true,true);
	m_panelManager.registerPanel(U"rail_timetable",Vec2{TrainTimetableEditor::kWidth,Min(TrainTimetableEditor::kHeight,Scene::Height()-40)},true,true);
	m_panelManager.registerPanel(U"building_info", Vec2{320, static_cast<double>(Scene::Height() - 20)}, true, true);
	m_panelManager.registerPanel(U"draw_template", Vec2{374, static_cast<double>(Scene::Height() - 20)}, true, true);

	m_panelManager.registerPanel(U"signal_edit", Vec2{700, 550}, true, true);
	m_panelManager.registerPanel(U"guide_sign_edit", Vec2{360, 600}, true, true);
	m_panelManager.registerPanel(U"guide_sign_editor", Vec2{500, 600}, true, true);
	m_panelManager.registerPanel(U"route_info", Vec2{312, static_cast<double>(Scene::Height() - 20)}, true, true);

	// 道路設置テンプレートの初期値（LocalRoad, 2車線）
	m_drawTemplate = RoadPlanDraft::makeRoadTemplate(0);

	m_roadPresets.load();

	if (getData().isNewGame)
		initNewGame();
	else
		initLoadGame();
}

void GameScene::initLoadGame()
{
	startLoadingPhase(LoadingTask::LoadGame, U"ロード中...", U"セーブデータを読み込み中...", [this]()
	{
		m_loadGameResult = loadGame();
	});
}

void GameScene::initNewGame()
{
	// 新規ゲーム開始時は地形から建物配置までの生成パイプラインを非同期ロード段階へ載せる。
	const auto initResult = MapGenerator::initWorld(getData().seed, m_world);
	m_placeNames = std::move(initResult.placeNames);

	m_world.reserveChunks();

	const float worldCenter = WORLD_SIZE * 0.5f;
	m_camera.setFocus(Vec3{ worldCenter, 0.0, worldCenter });

	m_totalInitChunks = WORLD_CHUNKS * WORLD_CHUNKS;

	startLoadingPhase(LoadingTask::NewGame, U"マップ生成中...", U"地形生成中", [this]()
	{
		m_world.generateRivers();
		generateAllTerrain();
		placeAllSettlements();
		generateAllRoads();
		generateDistrictRoads();
		postProcessRoads();
		MapGenerator::setupTrain(m_trainNetwork,m_world,m_districts,&m_network);
		m_districtHierarchy.generate(m_world,m_districts);
	m_network.recomputeAllAutoSigns();
	m_roadRenderer.setMunicipalityLookup([this](Vec2 point)
	{
		const int id=m_districtHierarchy.at(point,0);
		return id>=0 ? m_districtHierarchy.areas[id].name : U"";
	});
		applyZonesGlobal();
		placeInitialBuildings();
	});
	Logger << U"[Loading] {} チャンク生成開始"_fmt(m_totalInitChunks);
}

// =============================================================================
void GameScene::setLoadingTitleAndStatus(StringView title, StringView status)
{
	std::lock_guard lock(m_loadingTextMutex);
	m_loadingTitle  = title;
	m_loadingStatus = status;
}

void GameScene::setLoadingStatus(StringView status)
{
	std::lock_guard lock(m_loadingTextMutex);
	m_loadingStatus = status;
}

String GameScene::loadingTitleSnapshot() const
{
	std::lock_guard lock(m_loadingTextMutex);
	return m_loadingTitle;
}

String GameScene::loadingStatusSnapshot() const
{
	std::lock_guard lock(m_loadingTextMutex);
	return m_loadingStatus;
}

void GameScene::startLoadingPhase(LoadingTask task, StringView title, StringView status,
                                  std::function<void()> pipeline)
{
	// ローディング状態を初期化し、進捗表示用の文言と非同期処理を新しいフェーズへ切り替える。
	m_loadingTimer.restart();
	m_loadingTask = task;
	m_loadingFailed = false;
	m_loadingError.clear();
	m_loadGameResult = false;
	setLoadingTitleAndStatus(title, status);
	m_genProgress.store(0.0f);
	m_generationFuture = std::async(std::launch::async, std::move(pipeline));
	m_phase = GamePhase::Loading;
}

// =============================================================================
// バックグラウンド生成パイプライン
// =============================================================================

static constexpr float kProgressTerrain      = 0.00f;
static constexpr float kProgressSettlement   = 0.03f;
static constexpr float kProgressRoads        = 0.25f;
static constexpr float kProgressDistrict     = 0.74f;
static constexpr float kProgressPostProcess  = 0.79f;
static constexpr float kProgressDone         = 0.91f;

void GameScene::generateAllTerrain()
{
	setLoadingStatus(U"地形生成中");
	const Stopwatch sw{ StartImmediately::Yes };

	// 全チャンクの高さマップを並列生成し、完成後にワールドへ一括で反映する。
	const int total = WORLD_CHUNKS * WORLD_CHUNKS;
	const int nThreads = Max(1, static_cast<int>(std::thread::hardware_concurrency()));

	Array<HeightMapResult> buffer(total);

	std::atomic<int> counter{ 0 };
	Array<std::thread> threads;
	threads.reserve(nThreads);

	for (int t = 0; t < nThreads; ++t)
	{
		threads.emplace_back([this, &buffer, &counter, total]()
		{
			while (true)
			{
				const int idx = counter.fetch_add(1);
				if (idx >= total) break;
				const int cx = idx % WORLD_CHUNKS;
				const int cy = idx / WORLD_CHUNKS;
				buffer[idx] = m_world.buildHeightMap(Point{ cx, cy });
				m_genProgress.store(kProgressTerrain +
					(kProgressSettlement - kProgressTerrain) * static_cast<float>(idx + 1) / total);
			}
		});
	}

	for (auto& th : threads) th.join();

	for (int idx = 0; idx < total; ++idx)
	{
		const int cx = idx % WORLD_CHUNKS;
		const int cy = idx / WORLD_CHUNKS;
		m_world.installChunkDirect(Point{ cx, cy }, std::move(buffer[idx]));
	}

	m_genProgress.store(kProgressSettlement);
	Logger << U"[Phase1] 地形生成完了: {} チャンク ({:.1f}秒)"_fmt(total, sw.sF());
}

void GameScene::placeAllSettlements()
{
	setLoadingStatus(U"地区配置中");

	auto settlements = MapGenerator::placeAllSettlements(getData().seed, m_world);

	Array<BiomeType> biomes;
	biomes.reserve(settlements.size());
	for (const auto& s : settlements)
		biomes << m_world.getBiome(static_cast<float>(s.center.x), static_cast<float>(s.center.y));

	PlaceNameGenerator placeGen;
	placeGen.load(U"assets/placenames/placenames.toml");
	m_placeNames = placeGen.generateWithBiomes(
		static_cast<int>(settlements.size()), biomes, getData().seed);

	for (int i = 0; i < static_cast<int>(settlements.size()); ++i)
	{
		settlements[i].name    = m_placeNames.settlementName(i);
		settlements[i].reading = m_placeNames.settlementReading(i);
	}

	m_districts = settlements;
	m_castleTownCenters.clear();
	for (const auto& s : m_districts)
	{
		if (s.kind == MapGenerator::SettlementKind::RegionalCity)
			m_castleTownCenters << s.center;
	}

	m_genProgress.store(kProgressRoads);
}

void GameScene::generateAllRoads()
{
	setLoadingStatus(U"道路生成中");

	MapGenerator::generateGlobalRoads(
		getData().seed, m_districts, m_world, m_network,
		[this](float fraction) {
			m_genProgress.store(kProgressRoads +
				(kProgressDistrict - kProgressRoads) * fraction);
		});
}

void GameScene::generateDistrictRoads()
{
	setLoadingStatus(U"地区内道路生成中");
	m_genProgress.store(kProgressDistrict);

	MapGenerator::generateDistrictRoads(
		getData().seed, m_districts, m_world, m_network,
		[this](float fraction) {
			m_genProgress.store(kProgressDistrict +
				(kProgressPostProcess - kProgressDistrict) * fraction);
		});
}

void GameScene::postProcessRoads()
{
	setLoadingStatus(U"道路ポスト処理中");
	m_genProgress.store(kProgressPostProcess);

	// 道路生成後の形状補正、交差点整理、標識登録までを段階的に実行して走行可能なネットワークへ整える。
	const Stopwatch total{ StartImmediately::Yes };
	Stopwatch step{ StartImmediately::Yes };

	Logger << U"[PostProcess] 開始 (nodes={}, edges={})"_fmt(
		m_network.nodes().size(), m_network.edges().size());

	{
		int iter = 0;
		constexpr int kMaxIter = 1000;
		while (iter < kMaxIter && m_network.fixSharpAngles(45.0f))
			++iter;
		Logger << U"[PostProcess] fixSharpAngles: {} 回, {:.0f}ms"_fmt(iter, step.msF());
		if (getData().auditRoadIntegrity) RoadBinary::writeGlobal(U"integrity_fixSharpAngles.bin",m_network);
		step.restart();
	}

	m_network.smoothAllCurves();
	Logger << U"[PostProcess] smoothAllCurves: {:.0f}ms"_fmt(step.msF());
	if (getData().auditRoadIntegrity) RoadBinary::writeGlobal(U"integrity_smoothAllCurves.bin",m_network);
	step.restart();

	DistrictRoads::straightenCastleTownRoads(m_districts, m_world, m_network);
	DBG_LOG(U"[RoadDesignChains] repaired={}"_fmt(RoadDesignLimits::smoothThroughChains(m_network)));
	for (const auto& edge : m_network.edges())
	{
		if (edge.id >= 0) { RoadDesignLimits::constrainCurve(m_network, edge.id); }
	}
	for (const auto& edge : m_network.edges())
	{
		if (edge.id >= 0) m_network.getEdge(edge.id)->edgeState = EdgeState::Open;
	}
	m_network.resolveIntersections();
	m_network.consolidateOverlappingRoads();
	m_network.resolveIntersections();
	m_network.consolidateOverlappingRoads();
	m_network.removeDuplicateEdges(getData().seed);
	Logger << U"[PostProcess] reconcileRoadGeometry: {:.0f}ms"_fmt(step.msF());
	if (getData().auditRoadIntegrity) RoadBinary::writeGlobal(U"integrity_reconciled.bin",m_network);
	if (getData().auditRoadIntegrity)
	{
		for (const auto& district : m_districts)
		{
			if (!district.plan.ready || district.plan.frontageRoads) { continue; }
			const Vec2 interior = district.plan.halfExtent-Vec2{80,80};
			int tested=0, misaligned=0;
			double largestDrift=0;
			for (const auto& edge : m_network.edges())
			{
				if (edge.id<0) { continue; }
				const Vec3 a=m_network.getNode(edge.nodeA)->position,b=m_network.getNode(edge.nodeB)->position;
				const Vec2 localA{a.x-district.center.x,a.z-district.center.y},localB{b.x-district.center.x,b.z-district.center.y};
				if (Abs(localA.dot(district.gridAxisX))>interior.x || Abs(localA.dot(district.gridAxisZ))>interior.y
					|| Abs(localB.dot(district.gridAxisX))>interior.x || Abs(localB.dot(district.gridAxisZ))>interior.y) { continue; }
				++tested;
				const Vec2 direction=localB-localA;
				const double drift=Min(Abs(direction.dot(district.gridAxisX)),Abs(direction.dot(district.gridAxisZ)));
				largestDrift=Max(largestDrift,drift);
				misaligned+=(drift>0.1);
			}
			DBG_LOG(U"[TownGridIntegrity] center=({}, {}) edges={} misaligned={} maxDriftM={}"_fmt(district.center.x,district.center.y,tested,misaligned,largestDrift));
		}
	}
	step.restart();

	const auto auditDryStreets = [&](StringView stage)
	{
		double highest = 0; int raised = 0;
		for (const auto& node : m_network.nodes())
		{
			if (node.id < 0) { continue; }
			const double ground = m_world.sampleHeight(static_cast<float>(node.position.x), static_cast<float>(node.position.z));
			if (ground < m_world.waterSurfaceHeight(node.position.x, node.position.z) + 3.2) { continue; }
			const double gap = node.position.y - ground; highest = Max(highest, gap); raised += gap > 8;
		}
		DBG_LOG(U"[RoadHeightStage] stage={} raisedDryNodes={} maximumGap={}"_fmt(stage, raised, highest));
	};
	auditDryStreets(U"terrain");
	WaterCrossings::splitWaterSpans(m_network,
		[&](double x, double z) { return m_world.sampleHeight(static_cast<float>(x), static_cast<float>(z)); },
		[&](double x, double z) { return m_world.waterSurfaceHeight(x, z); });
	RoadVerticalAlignment::apply(m_network,m_world);
	auditDryStreets(U"vertical");
	const auto roadsBefore = RoadDesignLimits::measure(m_network, m_world);
	// Resolve infeasible hills before bridge approach heights can spread into adjacent towns.
	RoadDesignLimits::apply(m_network, m_world);
	auditDryStreets(U"alignment");
	const auto water=WaterCrossings::repair(m_network,[&](double x,double z) { return m_world.sampleHeight(static_cast<float>(x),static_cast<float>(z)); },[&](double x,double z) { return m_world.waterSurfaceHeight(x,z); });
	auditDryStreets(U"crossings");
	RoadDesignLimits::fitGrades(m_network, m_world);
	auditDryStreets(U"finalGrades");
	RoadTerrainFit::apply(m_network,m_world);
	const auto beforeJunctions=RoadDesignLimits::measure(m_network,m_world);
	const bool joinedTunnels=m_network.resolveIntersections();
	const auto afterJunctions=RoadDesignLimits::measure(m_network,m_world);
	if (joinedTunnels && (afterJunctions.gradeViolations>0 || afterJunctions.radiusViolations>0))
	{
		// A shared junction changes curve endpoints; re-establish their grade planes afterwards.
		RoadDesignLimits::fitGrades(m_network,m_world);
		RoadTerrainFit::apply(m_network,m_world);
	}
	DBG_LOG(U"[TunnelTopology] intersectionsAfterVerticalAlignment={} gradeBeforeJoin={} gradeAfterJoin={}"_fmt(joinedTunnels,beforeJunctions.gradeViolations,afterJunctions.gradeViolations));
	const auto roadsAfter = RoadDesignLimits::measure(m_network, m_world);
	DBG_LOG(U"[RoadDesignAudit] edges={} gradeBefore={} gradeAfter={} radiusBefore={} radiusAfter={} maxGrade={:.5f}"_fmt(
		roadsAfter.edges, roadsBefore.gradeViolations, roadsAfter.gradeViolations,
		roadsBefore.radiusViolations, roadsAfter.radiusViolations, roadsAfter.maximumGrade));
	JSON groundReport; int townIndex=0;
	for (const auto& district : m_districts)
	{
		if (district.kind!=MapGenerator::SettlementKind::RegionalCity) { continue; }
		int streets=0,elevated=0,tunnels=0; double largestClearance=0;
		const double radius=district.plan.ready ? Min(district.plan.halfExtent.x,district.plan.halfExtent.y)*.65 : 400;
		for (const auto& edge : m_network.edges())
		{
			if (edge.id<0) { continue; }
			const auto curve=m_network.getBezier(edge.id); const Vec3 point=curve->evaluate(.5f);
			if (Vec2{point.x,point.z}.distanceFrom(district.center)>radius) { continue; }
			++streets; elevated+=edge.useElevation && !edge.tunnel; tunnels+=edge.tunnel;
			largestClearance=Max(largestClearance,point.y-m_world.sampleHeight(static_cast<float>(point.x),static_cast<float>(point.z)));
		}
		JSON item; item[U"center"]=Array<double>{district.center.x,district.center.y}; item[U"streets"]=streets;
		item[U"elevated"]=elevated; item[U"tunnels"]=tunnels; item[U"largestClearanceM"]=largestClearance;
		groundReport[U"towns"][townIndex++]=item;
		DBG_LOG(U"[TownRoadGround] center=({}, {}) streets={} elevated={} tunnels={} maxClearanceM={:.2f}"_fmt(district.center.x,district.center.y,streets,elevated,tunnels,largestClearance));
	}
	groundReport[U"gradeViolations"]=roadsAfter.gradeViolations; groundReport[U"radiusViolations"]=roadsAfter.radiusViolations;
	groundReport.save(U"road_ground_audit.json");
	DBG_LOG(U"[NarrowBlockMerge] removedShortcuts={}"_fmt(StreetBlocks::mergeNarrowFaces(m_network)));
	for (const auto& edge : m_network.edges())
	{
		if (edge.id>=0 && edge.useElevation && !edge.tunnel) { m_network.generatePiersForEdge(edge.id,m_world); }
	}
	DBG_LOG(U"[WaterCrossings] wetBefore={} elevatedEdges={}"_fmt(water.wetEdges,water.elevatedEdges));
	{
		double wetLength=0,parallelLength=0,maxBridgeGrade=0;int bridges=0,submerged=0;
		for (const auto& edge : m_network.edges())
		{
			if (edge.id<0 || edge.tunnel) { continue; }
			const auto curve=m_network.getBezier(edge.id);bool wet=false;
			for (float arc=0;arc<curve->totalLength;arc+=6)
			{
				const Vec3 p=curve->positionAt(arc),tangent=curve->tangentAt(arc);
				const double ground=m_world.sampleHeight(static_cast<float>(p.x),static_cast<float>(p.z)),waterLevel=m_world.waterSurfaceHeight(p.x,p.z);
				if (ground>=waterLevel+1) { continue; }
				wet=true;wetLength+=6;submerged+=(edge.usesDesignHeight() ? p.y : ground)<waterLevel;
				maxBridgeGrade=Max(maxBridgeGrade,Abs(tangent.y)/Max(.001,Vec2{tangent.x,tangent.z}.length()));
				const auto river=m_world.rivers().nearest({p.x,p.z});
				if (river.reach>=0 && river.distance<river.halfWidth)
				{
					const auto& reach=m_world.rivers().reaches[river.reach];const Vec2 flow{reach.end.x-reach.start.x,reach.end.z-reach.start.z};
					if (Abs(flow.normalized().dot(Vec2{tangent.x,tangent.z}.normalized()))>.8) { parallelLength+=6; }
				}
			}
			bridges+=wet;
		}
		DBG_LOG(U"[BridgeAlignmentAudit] wetEdges={} waterLengthM={} parallelWaterLengthM={} maxWaterGrade={} submergedSamples={}"_fmt(bridges,wetLength,parallelLength,maxBridgeGrade,submerged));
	}
	if (getData().auditRoadIntegrity)
	{
		int wetRoads=0;
		for (const auto& edge : m_network.edges())
		{
			if (edge.id<0) { continue; } const auto curve=m_network.getBezier(edge.id);bool wet=false;
			for (float arc=0;arc<=curve->totalLength;arc+=4)
			{
				const Vec3 point=curve->positionAt(arc),right=tangentToRight(curve->tangentAt(arc));
				for (const int side : {-1,0,1})
				{
					const Vec3 p=point+right*(edge.totalWidth()*.5*side);const double ground=m_world.sampleHeight(static_cast<float>(p.x),static_cast<float>(p.z)),surface=m_world.waterSurfaceHeight(p.x,p.z);
					const double pavement=edge.usesDesignHeight() ? point.y : ground;
					wet|=ground<surface && pavement<surface-.03 && !(edge.tunnel && pavement<ground-6);
				}
			}
			wetRoads+=wet;
		}
		DBG_LOG(U"[RoadWaterAudit] submergedRoads={}"_fmt(wetRoads));
	}

	{
		int elevated=0,low=0,buried=0;
		for (const auto& edge : m_network.edges())
		{
			if (edge.id<0 || !edge.useElevation) { continue; }
			++elevated; double maximum=-1e9,minimum=1e9;
			const auto curve=m_network.getBezier(edge.id);
			for (int i=0;i<=20;++i) { const auto point=curve->evaluate(i/20.0f); const double gap=point.y-m_world.sampleHeight(static_cast<float>(point.x),static_cast<float>(point.z)); maximum=Max(maximum,gap); minimum=Min(minimum,gap); }
			low+=maximum<2; buried+=minimum<-.05;
		}
		DBG_LOG(U"[RoadGroundAudit] elevated={} belowTwoMeters={} buried={}"_fmt(elevated,low,buried));
	}
	registerGuideDestinations();
	Logger << U"[PostProcess] registerGuideDestinations: {:.0f}ms"_fmt(step.msF());
	step.restart();

	// 初期生成された道路はすべて建設済み（供用中）とする
	for (const auto& edge : m_network.edges())
	{
		if (edge.id < 0) continue;
		if (RoadEdge* e = m_network.getEdge(edge.id)) e->edgeState = EdgeState::Open;
	}

	m_genProgress.store(kProgressDone);
	Logger << U"[Phase4] PostProcess 完了 ({:.0f}ms)"_fmt(total.msF());
}

// =============================================================================
// 案内標識: NamedDestination 登録 + 自動生成 (plan/21_guide_sign_spec.md)
// =============================================================================

void GameScene::registerGuideDestinations()
{
	// 地区データを道路ノード上の目的地辞書へ写し替え、自動案内標識の再生成まで一気に行う。
	m_network.clearNamedDestinations();

	const auto tierOf = [](MapGenerator::SettlementKind t) -> uint8 {
		switch (t)
		{
		case MapGenerator::SettlementKind::RegionalCity:   return 0;
		case MapGenerator::SettlementKind::LocalTown: return 1;
		case MapGenerator::SettlementKind::RuralSettlement:   return 2;
		}
		return 2;
	};

	int registered = 0;
	for (const auto& s : m_districts)
	{
		if (s.name.isEmpty()) continue;

		// 地区中心から最寄り RoadNode を線形検索
		const Vec3 target{ s.center.x, 0.0, s.center.y };
		int   bestNode = -1;
		float bestDistSq = std::numeric_limits<float>::max();
		for (const auto& n : m_network.nodes())
		{
			if (n.id < 0 || n.attachments.isEmpty()) { continue; }
			const float dx = static_cast<float>(n.position.x - target.x);
			const float dz = static_cast<float>(n.position.z - target.z);
			const float d2 = dx * dx + dz * dz;
			if (d2 < bestDistSq)
			{
				bestDistSq = d2;
				bestNode = n.id;
			}
		}
		if (bestNode < 0) continue;

		m_network.addNamedDestination(bestNode, s.name, s.reading, tierOf(s.kind));
		++registered;
	}

	m_network.recomputeAllAutoGuideSigns();
	Logger << U"[GuideSign] {} 地区を登録, 案内標識自動生成完了"_fmt(registered);
}

// =============================================================================
// Loading フェーズ更新
// =============================================================================

void GameScene::updateLoading()
{
	// バックグラウンド生成の完了待ちと、成功時の最終初期化・失敗時の画面維持をここで分岐する。
	if (m_generationFuture.valid())
	{
		if (m_generationFuture.wait_for(std::chrono::seconds(0)) == std::future_status::ready)
		{
			try
			{
				m_generationFuture.get();
			}
			catch (const std::exception& e)
			{
				m_loadingFailed = true;
				m_loadingError = Unicode::Widen(e.what());
				setLoadingStatus(U"ロード/生成中に例外が発生しました");
				Logger << U"[Loading] Exception: " << m_loadingError;
				DBG_LOG(U"[Loading] Exception: {}"_fmt(m_loadingError));
				if (getData().auditRoadIntegrity) System::Exit();
			}
			catch (...)
			{
				m_loadingFailed = true;
				m_loadingError = U"unknown exception";
				setLoadingStatus(U"ロード/生成中に例外が発生しました");
				Logger << U"[Loading] Unknown exception";
			}

			if (m_loadingFailed)
			{
				drawLoadingScreen(Clamp(m_genProgress.load(), 0.0f, 1.0f));
				return;
			}

			if (m_loadingTask == LoadingTask::LoadGame)
			{
				if (!m_loadGameResult)
				{
					m_loadingFailed = true;
					m_loadingError = U"loadGame() returned false";
					setLoadingStatus(U"ロードに失敗しました。セーブデータの整合性を確認してください");
					Logger << U"[Load] Failed ({:.1f}秒)"_fmt(m_loadingTimer.sF());
					drawLoadingScreen(Clamp(m_genProgress.load(), 0.0f, 1.0f));
					return;
				}

				Logger << U"[Load] 完了 ({:.1f}秒)"_fmt(m_loadingTimer.sF());
				m_riverRenderer.build(m_world);
			m_tunnelRenderer.build(m_world,m_network,m_trainNetwork);
			m_worldRenderer.setTunnelOpenings(m_tunnelRenderer.openings);
			m_minimapRenderer.setGeography(m_world,m_districtHierarchy);
			m_minimapRenderer.buildTerrainTexture(m_world);
				m_minimapRenderer.updateRoadOverlay(m_network, m_world);
				m_worldRenderer.preloadBuildingModels();
			m_roadRenderer.preloadFallbacks(m_network,m_world);
			m_housingCapacity.update(m_world,WORLD_CHUNKS*WORLD_CHUNKS);
			m_phase = GamePhase::Playing;
				return;
			}

			Logger << U"[Loading] 全パイプライン完了 ({:.1f}秒)"_fmt(m_loadingTimer.sF());
			setLoadingStatus(U"初期化中...");

			m_roadRenderer.invalidateAllCaches();

			Vec3 cameraFocus{WORLD_SIZE*.5,0,WORLD_SIZE*.5}; double bestArea=0;
			for (const auto& town : m_districts)
			{
				const double area=town.plan.halfExtent.x*town.plan.halfExtent.y;
				if (!town.plan.frontageRoads && town.plan.scale==0 && area>bestArea)
				{
					bestArea=area; cameraFocus={town.center.x,m_world.sampleHeight(static_cast<float>(town.center.x),static_cast<float>(town.center.y)),town.center.y};
				}
			}
			m_camera.setFocus(cameraFocus);
			m_world.update(m_camera.focusPoint());

			startSimThread();

			m_riverRenderer.build(m_world);
			m_tunnelRenderer.build(m_world,m_network,m_trainNetwork);
			m_worldRenderer.setTunnelOpenings(m_tunnelRenderer.openings);
			m_minimapRenderer.setGeography(m_world,m_districtHierarchy);
			m_minimapRenderer.buildTerrainTexture(m_world);
			m_minimapRenderer.updateRoadOverlay(m_network, m_world);

			Logger << U"[Phase] 全体 {:.1f}秒 → Playing へ遷移"_fmt(m_loadingTimer.sF());
			m_worldRenderer.preloadBuildingModels();
			m_roadRenderer.preloadFallbacks(m_network,m_world);
			m_housingCapacity.update(m_world,WORLD_CHUNKS*WORLD_CHUNKS);
			m_economy.initializeGeneratedCity(m_housingCapacity.capacity());
			DBG_LOG(U"[InitialEconomy] housing={} population={} grant={:.3f} maintenance={:.3f}"_fmt(
				m_housingCapacity.capacity(),m_economy.population,m_economy.monthlyGrant(),m_economy.roadMaintenanceCost(m_network)));
			m_phase = GamePhase::Playing;
			return;
		}
	}

	drawLoadingScreen(Clamp(m_genProgress.load(), 0.0f, 1.0f));
}

// =============================================================================
// SimThread 起動
// =============================================================================

void GameScene::startSimThread()
{
	m_simGraph = std::make_shared<const SimGraph>(SimGraph::build(m_network));
	m_vehicleManager.init(*m_simGraph, m_network, &m_world);
	m_citySnapshot = collectCitySnapshot(m_world, m_network, m_vehicleManager.vehicles());
	m_simThread.start(m_simGraph);
}

// =============================================================================
// ローディング画面描画
// =============================================================================

void GameScene::drawLoadingScreen(float progress)
{
	Scene::Rect().draw(ColorF{ 0.07, 0.11, 0.16 });

	const auto& titleFont = FontAsset(Asset::TitleBold48);
	const auto& uiFont    = FontAsset(Asset::UI20);
	const auto& smallFont = FontAsset(Asset::Small16);

	const Vec2 center = Scene::Center();
	const String loadingTitle = loadingTitleSnapshot();
	const String loadingStatus = loadingStatusSnapshot();

	const int elapsedSec = static_cast<int>(m_loadingTimer.sF());
	const int min = elapsedSec / 60;
	const int sec = elapsedSec % 60;
	uiFont(U"{}:{:0>2}"_fmt(min, sec)).drawAt(
		center.movedBy(0, -110), ColorF{ 0.7 });

	titleFont(loadingTitle).drawAt(center.movedBy(0, -60), ColorF{ 0.9 });

	const RectF barBg{ center.x - 200, center.y, 400, 24 };
	barBg.draw(ColorF{ 0.2 });
	RectF{ barBg.pos, barBg.w * progress, barBg.h }.draw(ColorF{ 0.3, 0.7, 1.0 });

	uiFont(U"{}%"_fmt(static_cast<int>(progress * 100))).drawAt(barBg.center(), ColorF{ 1.0 });

	const ColorF statusColor = m_loadingFailed ? ColorF{ 1.0, 0.45, 0.45 } : ColorF{ 0.5 };
	smallFont(loadingStatus).drawAt(center.movedBy(0, 70), statusColor);

	if (m_loadingFailed && !m_loadingError.isEmpty())
	{
		const String clipped = m_loadingError.substr(0, Min<size_t>(80, m_loadingError.size()));
		smallFont(U"Error: {}"_fmt(clipped)).drawAt(center.movedBy(0, 94), ColorF{ 0.85, 0.35, 0.35 });
	}
}

// =============================================================================
// セーブ / ロード
// =============================================================================

void GameScene::saveGame()
{
	if (getData().saveName.isEmpty())
	{
		getData().saveName = U"default";
	}
	if (getData().saveName.contains(U'/') || getData().saveName.contains(U'\\')
		|| getData().saveName == U"." || getData().saveName == U"..")
	{
		DebugLog::print(U"[Save] Invalid save name: {}"_fmt(getData().saveName));
		return;
	}

	const FilePath saveRoot = U"saves/{}"_fmt(getData().saveName);
	const SaveResult result = SaveTransaction::commit(saveRoot,
		[this](const FilePath& temporaryDirectory)
		{
			return writeGameSnapshot(temporaryDirectory);
		},
		[this](const FilePath& temporaryDirectory)
		{
			return verifyGameSnapshot(temporaryDirectory);
		});

	if (result)
	{
		DebugLog::print(U"[Save] Saved atomically to {}"_fmt(result.path));
	}
	else
	{
		DebugLog::print(U"[Save] Failed: {} ({})"_fmt(result.message, result.path));
	}
}

SaveResult GameScene::writeGameSnapshot(const FilePath& saveRoot) const
{
	constexpr int kSaveVersion = 3;
	const FilePath globalDirectory = saveRoot + U"/global";
	if (!FileSystem::CreateDirectories(globalDirectory))
	{
		return SaveResult::failed(SaveError::WriteFailed,
			U"global ディレクトリを作成できません", globalDirectory);
	}

	JSON meta;
	meta[U"version"] = kSaveVersion;
	meta[U"roadGeometryVersion"] = 1;
	meta[U"zoneDevelopment"] = m_zoneManager.saveState(m_world);
	meta[U"railway"] = m_trainNetwork.saveState();
	meta[U"seed"] = getData().seed;
	meta[U"worldChunks"] = WORLD_CHUNKS;
	meta[U"gameNow"] = m_clock.now;
	meta[U"timeScale"] = static_cast<int>(m_clock.speed);
	meta[U"nextNodeId"] = m_network.nextNodeId();
	meta[U"nextEdgeId"] = m_network.nextEdgeId();
	meta[U"cameraFocusX"] = m_camera.focusPoint().x;
	meta[U"cameraFocusY"] = m_camera.focusPoint().y;
	meta[U"cameraFocusZ"] = m_camera.focusPoint().z;
	meta[U"cameraDistance"] = m_camera.distance();
	meta[U"cameraYaw"] = m_camera.yaw();
	meta[U"cameraPitch"] = m_camera.pitch();
	if (!meta.save(saveRoot + U"/meta.json"))
	{
		return SaveResult::failed(SaveError::WriteFailed, U"meta.json を保存できません", saveRoot);
	}

	JSON economy;
	economy[U"funds"] = m_economy.funds;
	economy[U"population"] = m_economy.population;
	economy[U"happiness"] = m_economy.happiness;
	if (!economy.save(globalDirectory + U"/economy.json"))
	{
		return SaveResult::failed(SaveError::WriteFailed, U"economy.json を保存できません", saveRoot);
	}
	if (!RoadBinary::writeGlobal(globalDirectory + U"/roads.bin", m_network))
	{
		return SaveResult::failed(SaveError::WriteFailed, U"roads.bin を保存できません", saveRoot);
	}
	if (!m_clearanceLedger.save(globalDirectory + U"/construction_clearance.json"))
	{
		return SaveResult::failed(SaveError::WriteFailed,U"撤去した区画を保存できません",globalDirectory);
	}
	if (!GuideSignStorage::writeJson(globalDirectory + U"/guide_signs.json", m_network))
	{
		return SaveResult::failed(SaveError::WriteFailed, U"guide_signs.json を保存できません", saveRoot);
	}

	JSON districts;
	districts[U"count"] = static_cast<int>(m_districts.size());
	districts[U"morphologyVersion"] = 2;
	for (int index = 0; index < static_cast<int>(m_districts.size()); ++index)
	{
		const auto& settlement = m_districts[index];
		districts[U"type_{}"_fmt(index)] = static_cast<int>(settlement.kind);
		districts[U"cx_{}"_fmt(index)] = settlement.center.x;
		districts[U"cy_{}"_fmt(index)] = settlement.center.y;
		districts[U"radius_{}"_fmt(index)] = settlement.radius;
		districts[U"score_{}"_fmt(index)] = settlement.score;
		districts[U"name_{}"_fmt(index)] = settlement.name;
		districts[U"reading_{}"_fmt(index)] = settlement.reading;
		const auto& plan=settlement.plan;
		districts[U"origin_{}"_fmt(index)]=static_cast<int>(plan.origin);
		districts[U"ruralForm_{}"_fmt(index)]=static_cast<int>(plan.ruralForm);
		districts[U"halfX_{}"_fmt(index)]=plan.halfExtent.x;
		districts[U"halfZ_{}"_fmt(index)]=plan.halfExtent.y;
		districts[U"axisX_{}"_fmt(index)]=settlement.gridAxisX.x;
		districts[U"axisZ_{}"_fmt(index)]=settlement.gridAxisX.y;
		districts[U"railway_{}"_fmt(index)]=plan.station.has_value();
		districts[U"frontage_{}"_fmt(index)]=plan.frontageRoads;
		districts[U"oldX_{}"_fmt(index)]=plan.oldCore.x;
		districts[U"oldZ_{}"_fmt(index)]=plan.oldCore.y;
		if (plan.station)
		{
			districts[U"stationX_{}"_fmt(index)]=plan.station->x;
			districts[U"stationZ_{}"_fmt(index)]=plan.station->y;
		}
		districts[U"civic_{}"_fmt(index)]=plan.civic.has_value();
		const RectF civic=plan.civic.value_or(RectF{0,0,0,0});
		districts[U"civicX_{}"_fmt(index)]=civic.x; districts[U"civicZ_{}"_fmt(index)]=civic.y;
		districts[U"civicW_{}"_fmt(index)]=civic.w; districts[U"civicH_{}"_fmt(index)]=civic.h;
		districts[U"industryX_{}"_fmt(index)]=plan.industry.x; districts[U"industryZ_{}"_fmt(index)]=plan.industry.y;
		districts[U"industryW_{}"_fmt(index)]=plan.industry.w; districts[U"industryH_{}"_fmt(index)]=plan.industry.h;
		districts[U"fringe_{}"_fmt(index)]=static_cast<int>(plan.fringeStreets.size());
		for (size_t street=0;street<plan.fringeStreets.size();++street)
		{
			const auto& line=plan.fringeStreets[street];
			districts[U"fringeAX_{}_{}"_fmt(index,street)]=line.begin.x;
			districts[U"fringeAZ_{}_{}"_fmt(index,street)]=line.begin.y;
			districts[U"fringeBX_{}_{}"_fmt(index,street)]=line.end.x;
			districts[U"fringeBZ_{}_{}"_fmt(index,street)]=line.end.y;
		}
		districts[U"homes_{}"_fmt(index)]=static_cast<int>(plan.ruralHomes.size());
		for (size_t home=0;home<plan.ruralHomes.size();++home)
		{
			districts[U"homeX_{}_{}"_fmt(index,home)]=plan.ruralHomes[home].x;
			districts[U"homeZ_{}_{}"_fmt(index,home)]=plan.ruralHomes[home].y;
		}
	}
	if (!districts.save(globalDirectory + U"/districts.json"))
	{
		return SaveResult::failed(SaveError::WriteFailed, U"districts.json を保存できません", saveRoot);
	}

	const FilePath chunksDirectory = saveRoot + U"/chunks";
	for (int chunkY = 0; chunkY < WORLD_CHUNKS; ++chunkY)
	{
		for (int chunkX = 0; chunkX < WORLD_CHUNKS; ++chunkX)
		{
			const Chunk* chunk = m_world.getChunk(Point{ chunkX, chunkY });
			if (!chunk || chunk->heightMap.isEmpty())
			{
				continue;
			}

			const FilePath chunkDirectory = U"{}/{}_{}"_fmt(chunksDirectory, chunkX, chunkY);
			if (!FileSystem::CreateDirectories(chunkDirectory))
			{
				return SaveResult::failed(SaveError::WriteFailed,
					U"チャンクディレクトリを作成できません", chunkDirectory);
			}
			BinaryWriter writer{ chunkDirectory + U"/terrain.bin" };
			if (!writer)
			{
				return SaveResult::failed(SaveError::WriteFailed,
					U"terrain.bin を作成できません", chunkDirectory);
			}

			const int gridSize = HEIGHT_CELLS + 1;
			writer.write(static_cast<int32>(gridSize));
			for (int row = 0; row < gridSize; ++row)
			{
				for (int col = 0; col < gridSize; ++col)
				{
					writer.write(chunk->heightMap[{ col, row }]);
				}
			}
			BinaryWriter landWriter{ chunkDirectory + U"/land_patches.bin" };
			if (!landWriter)
			{
				return SaveResult::failed(SaveError::WriteFailed,
					U"land_patches.bin を作成できません", chunkDirectory);
			}
			landWriter.write(static_cast<uint32>(chunk->landPatches.size()));
			for (const LandPatch& patch : chunk->landPatches)
			{
				landWriter.write(static_cast<int32>(patch.id));
				landWriter.write(static_cast<uint8>(patch.type));
				landWriter.write(patch.elevationOffset);
				landWriter.write(patch.materialVariant);
				landWriter.write(static_cast<int64>(patch.sourceParcelKey));
				landWriter.write(static_cast<uint32>(patch.polygon.size()));
				for (const Vec2& point : patch.polygon)
				{
					landWriter.write(static_cast<float>(point.x));
					landWriter.write(static_cast<float>(point.y));
				}
			}
		}
	}
	return SaveResult::succeeded(saveRoot);
}

SaveResult GameScene::verifyGameSnapshot(const FilePath& saveRoot) const
{
	constexpr int kSaveVersion = 3;
	const FilePath metaPath = saveRoot + U"/meta.json";
	const FilePath economyPath = saveRoot + U"/global/economy.json";
	const FilePath roadsPath = saveRoot + U"/global/roads.bin";
	const JSON meta = JSON::Load(metaPath);
	if (!meta)
	{
		return SaveResult::failed(SaveError::MissingData, U"meta.json がありません", metaPath);
	}
	const int version = meta[U"version"].getOr<int>(0);
	if (version <= 0 || version > kSaveVersion)
	{
		return SaveResult::failed(SaveError::UnsupportedVersion,
			U"未対応のセーブバージョンです: {}"_fmt(version), metaPath);
	}
	if (!JSON::Load(economyPath))
	{
		return SaveResult::failed(SaveError::CorruptData,
			U"economy.json が欠損または破損しています", economyPath);
	}
	const FilePath clearancePath = saveRoot + U"/global/construction_clearance.json";
	if (FileSystem::IsFile(clearancePath))
	{
		RoadConstruction::ClearanceLedger verification;
		if (!verification.load(clearancePath))
			return SaveResult::failed(SaveError::CorruptData,U"撤去区画の記録が破損しています",clearancePath);
	}
	if (!FileSystem::IsFile(roadsPath) || FileSystem::FileSize(roadsPath) <= 0)
	{
		return SaveResult::failed(SaveError::MissingData,
			U"roads.bin が欠損しています", roadsPath);
	}
	return SaveResult::succeeded(saveRoot);
}
// =============================================================================
// 地形チャンク並列ロード（loadGame のサブルーチン）
// =============================================================================

void GameScene::loadTerrainChunks(const String& saveRoot, Stopwatch& step)
{
	// 地形チャンクは並列に読み戻し、欠損しているものだけ再生成してロード失敗を吸収する。
	// 地形データ（チャンクごとに並列読み込み + バルク I/O）
	const int totalChunks = WORLD_CHUNKS * WORLD_CHUNKS;
	setLoadingStatus(U"地形データ読み込み中...");
	{
		Array<HeightMapResult> buffer(totalChunks);
		std::atomic<int> counter{ 0 };
		std::atomic<int> loadedAtomic{ 0 };
		const int nThreads = Max(1, static_cast<int>(std::thread::hardware_concurrency()));
		Array<std::thread> threads;
		threads.reserve(nThreads);

		for (int t = 0; t < nThreads; ++t)
		{
			threads.emplace_back([this, &buffer, &counter, &loadedAtomic, totalChunks, &saveRoot]()
			{
				while (true)
				{
					const int idx = counter.fetch_add(1);
					if (idx >= totalChunks) break;
					const int cx = idx % WORLD_CHUNKS;
					const int cy = idx / WORLD_CHUNKS;

					const String terrainPath = U"{}/chunks/{}_{}/terrain.bin"_fmt(saveRoot, cx, cy);
					bool loaded = false;

					if (FileSystem::Exists(terrainPath))
					{
						BinaryReader r{ terrainPath };
						if (r)
						{
							int32 gridSize = 0;
							if (r.read(gridSize) && gridSize == HEIGHT_CELLS + 1)
							{
								HeightMapResult hmr;
								hmr.heightMap = Grid<float>(gridSize, gridSize);
								// バルク読み込み: gridSize² 個の float を1 回で取得
								const size_t cellCount = static_cast<size_t>(gridSize) * gridSize;
								const int64 expectedBytes = static_cast<int64>(cellCount * sizeof(float));
								if (r.read(hmr.heightMap.data(), static_cast<size_t>(expectedBytes)) == expectedBytes)
								{
									// min/max は読み込み完了後にまとめて算出
									float mn =  1e30f, mx = -1e30f;
									const float* p = hmr.heightMap.data();
									for (size_t i = 0; i < cellCount; ++i) { mn = Min(mn, p[i]); mx = Max(mx, p[i]); }
									hmr.heightMin = mn;
									hmr.heightMax = mx;
									buffer[idx] = std::move(hmr);
									loaded = true;
								}
							}
						}
					}

					if (!loaded)
					{
						buffer[idx] = m_world.buildHeightMap(Point{ cx, cy });
					}
					const int done = loadedAtomic.fetch_add(1) + 1;
					m_genProgress.store(static_cast<float>(done) / static_cast<float>(totalChunks) * 0.7f);
				}
			});
		}
		for (auto& th : threads) th.join();

		// installChunkDirect は m_world 内部状態を変更するためメインスレッドで直列に
		for (int idx = 0; idx < totalChunks; ++idx)
		{
			const int cx = idx % WORLD_CHUNKS;
			const int cy = idx / WORLD_CHUNKS;
			m_world.installChunkDirect(Point{ cx, cy }, std::move(buffer[idx]));
			Chunk* chunk = m_world.getChunk(Point{ cx, cy });
			if (!chunk) continue;
			const String landPath = U"{}/chunks/{}_{}/land_patches.bin"_fmt(saveRoot, cx, cy);
			if (!FileSystem::Exists(landPath)) continue;
			BinaryReader landReader{ landPath };
			if (!landReader) continue;
			uint32 patchCount = 0;
			if (!landReader.read(patchCount) || patchCount > 4096) continue;
			chunk->landPatches.clear();
			for (uint32 p = 0; p < patchCount; ++p)
			{
				LandPatch patch;
				int32 id = -1;
				uint8 type = 0;
				int64 sourceParcelKey = -1;
				uint32 pointCount = 0;
				if (!landReader.read(id) || !landReader.read(type) || !landReader.read(patch.elevationOffset)
					|| !landReader.read(patch.materialVariant) || !landReader.read(sourceParcelKey)
					|| !landReader.read(pointCount) || pointCount > 64)
				{
					chunk->landPatches.clear();
					break;
				}
				patch.id = static_cast<int>(id);
				patch.type = static_cast<LandPatchType>(type);
				patch.sourceParcelKey = sourceParcelKey;
				for (uint32 pointIndex = 0; pointIndex < pointCount; ++pointIndex)
				{
					float px = 0.0f, py = 0.0f;
					if (!landReader.read(px) || !landReader.read(py))
					{
						patch.polygon.clear();
						break;
					}
					patch.polygon << Vec2{ px, py };
				}
				if (patch.polygon.size() >= 3)
				{
					chunk->landPatches << patch;
				}
			}
		}
	}

	Console << U"[Load] terrain: {:.0f}ms"_fmt(step.msF());
	step.restart();
}

// =============================================================================
// ゲームデータ保存・ロード
// =============================================================================

bool GameScene::loadGame()
{
	const Stopwatch loadTotal{ StartImmediately::Yes };
	Stopwatch step{ StartImmediately::Yes };

	// セーブ一式を読み戻し、道路・地区・建物・時計・カメラまでプレイ直前の状態に復元する。
	const String saveRoot = U"saves/{}"_fmt(getData().saveName);

	// meta.json
	const JSON meta = JSON::Load(U"{}/meta.json"_fmt(saveRoot));
	if (!meta) return false;

	getData().seed    = meta[U"seed"].get<uint64>();
	const double gameNow    = meta[U"gameNow"].get<double>();
	const int    timeScale  = meta[U"timeScale"].get<int>();
	const int    nextNodeId = meta[U"nextNodeId"].get<int>();
	const int    nextEdgeId = meta[U"nextEdgeId"].get<int>();
	const double focusX     = meta[U"cameraFocusX"].get<double>();
	const double focusY     = meta[U"cameraFocusY"].get<double>();
	const double focusZ     = meta[U"cameraFocusZ"].get<double>();
	const float  camDist    = meta[U"cameraDistance"].getOr<float>(600.0f);
	const float  camYaw     = meta[U"cameraYaw"].getOr<float>(0.0f);
	const float  camPitch   = meta[U"cameraPitch"].getOr<float>(static_cast<float>(40.0_deg));

	m_world.setGenerationParams(getData().seed,
		WORLD_SIZE,
		WORLD_SIZE);
	m_world.generateRivers();
	m_world.reserveChunks();
	Console << U"[Load] meta+init: {:.0f}ms"_fmt(step.msF());
	step.restart();

	loadTerrainChunks(saveRoot, step);

	// 経済
	if (const JSON eco = JSON::Load(U"{}/global/economy.json"_fmt(saveRoot)))
	{
		m_economy.funds      = eco[U"funds"].get<double>();
		m_economy.population = eco[U"population"].get<int>();
		m_economy.happiness  = eco[U"happiness"].get<double>();
	}

	// 道路ネットワーク
	{
		const String roadPath = U"{}/global/roads.bin"_fmt(saveRoot);
		const bool roadOk = RoadBinary::readGlobal(roadPath, m_network);
		// 案内標識（独立 JSON。テクスチャは render 時に prepareGuideSignTextures で合成）
		m_network.clearGuideSigns();
		GuideSignStorage::readJson(U"{}/global/guide_signs.json"_fmt(saveRoot), m_network);
		Console << U"[Load] roads: " << (roadOk ? U"OK" : U"FAILED (format mismatch? re-save needed)")
		        << U" nodes=" << m_network.nodes().size()
		        << U" edges=" << m_network.edges().size();
	}
	m_network.setNextIds(nextNodeId, nextEdgeId);

	m_genProgress.store(0.8f);
	setLoadingStatus(U"道路・経済データ復元完了");
	Console << U"[Load] economy+roads: {:.0f}ms"_fmt(step.msF());
	step.restart();

	// 集落
	m_districts.clear();
	m_castleTownCenters.clear();
	if (const JSON dist = JSON::Load(U"{}/global/districts.json"_fmt(saveRoot)))
	{
		const int count = dist[U"count"].get<int>();
		Array<MapGenerator::Settlement> settlements;
		for (int i = 0; i < count; ++i)
		{
			MapGenerator::Settlement s;
			s.kind   = static_cast<MapGenerator::SettlementKind>(dist[U"type_{}"_fmt(i)].get<int>());
			s.center = Vec2{ dist[U"cx_{}"_fmt(i)].get<double>(), dist[U"cy_{}"_fmt(i)].get<double>() };
			s.name   = dist[U"name_{}"_fmt(i)].get<String>();
			const String radiusKey = U"radius_{}"_fmt(i);
			if (dist.hasElement(radiusKey))
				s.radius = dist[radiusKey].get<float>();
			else
			{
				// 旧セーブとの互換: 種別からデフォルト半径を復元
				s.radius = (s.kind == MapGenerator::SettlementKind::RegionalCity)   ? 700.0f
				         : (s.kind == MapGenerator::SettlementKind::LocalTown) ? 300.0f
				                                                             : 150.0f;
			}
			const String scoreKey = U"score_{}"_fmt(i);
			if (dist.hasElement(scoreKey))
				s.score = dist[scoreKey].get<float>();
			const String readingKey = U"reading_{}"_fmt(i);
			if (dist.hasElement(readingKey))
				s.reading = dist[readingKey].get<String>();
			const auto origin=static_cast<UrbanMorphology::Origin>(dist[U"origin_{}"_fmt(i)].getOr<int>(7));
			UrbanMorphology::Site site;
			const double halfZ=dist[U"halfZ_{}"_fmt(i)].getOr<double>(170);
			site.shoreDistance=halfZ+45;
			s.plan=UrbanMorphology::makePlan(origin,static_cast<uint8>(s.kind),site,
				UrbanMorphology::mix(getData().seed ^ (static_cast<uint64>(i)*0x9e3779b97f4a7c15ULL)),dist[U"railway_{}"_fmt(i)].getOr<bool>(false));
			s.plan.ruralForm=static_cast<UrbanMorphology::RuralForm>(dist[U"ruralForm_{}"_fmt(i)].getOr<int>(0));
			s.plan.halfExtent={dist[U"halfX_{}"_fmt(i)].getOr<double>(230),halfZ};
			s.plan.frontageRoads=dist[U"frontage_{}"_fmt(i)].getOr<bool>(false);
			s.plan.oldCore={dist[U"oldX_{}"_fmt(i)].getOr<double>(0),dist[U"oldZ_{}"_fmt(i)].getOr<double>(0)};
			if (s.plan.station) { s.plan.station=Vec2{dist[U"stationX_{}"_fmt(i)].getOr<double>(0),dist[U"stationZ_{}"_fmt(i)].getOr<double>(0)}; }
			if (dist[U"civic_{}"_fmt(i)].getOr<bool>(false))
			{
				s.plan.civic=RectF{dist[U"civicX_{}"_fmt(i)].get<double>(),dist[U"civicZ_{}"_fmt(i)].get<double>(),dist[U"civicW_{}"_fmt(i)].get<double>(),dist[U"civicH_{}"_fmt(i)].get<double>()};
			}
			s.plan.industry=RectF{dist[U"industryX_{}"_fmt(i)].getOr<double>(0),dist[U"industryZ_{}"_fmt(i)].getOr<double>(0),dist[U"industryW_{}"_fmt(i)].getOr<double>(0),dist[U"industryH_{}"_fmt(i)].getOr<double>(0)};
			for (int home=0;home<dist[U"homes_{}"_fmt(i)].getOr<int>(0);++home)
			{
				s.plan.ruralHomes << Vec2{dist[U"homeX_{}_{}"_fmt(i,home)].get<double>(),dist[U"homeZ_{}_{}"_fmt(i,home)].get<double>()};
			}
			for (int street=0;street<dist[U"fringe_{}"_fmt(i)].getOr<int>(0);++street)
			{
				s.plan.fringeStreets << Line{
					Vec2{dist[U"fringeAX_{}_{}"_fmt(i,street)].get<double>(),dist[U"fringeAZ_{}_{}"_fmt(i,street)].get<double>()},
					Vec2{dist[U"fringeBX_{}_{}"_fmt(i,street)].get<double>(),dist[U"fringeBZ_{}_{}"_fmt(i,street)].get<double>()}};
			}
			s.gridAxisX={dist[U"axisX_{}"_fmt(i)].getOr<double>(1),dist[U"axisZ_{}"_fmt(i)].getOr<double>(0)};
			s.gridAxisZ={-s.gridAxisX.y,s.gridAxisX.x};
			settlements << s;
		}
		addDistricts(settlements);
	}

	// Upgrade only the loaded in-memory graph; saving remains an explicit user operation.
	if (!meta.hasElement(U"roadGeometryVersion") || meta[U"roadGeometryVersion"].getOr<int>(0) < 1)
	{
		setLoadingStatus(U"重複する道路の接続を修復中...");
		m_network.consolidateOverlappingRoads();
	}
	m_genProgress.store(0.9f);
	setLoadingStatus(U"ゾーン・建物を復元中...");

	if (meta.hasElement(U"railway"))
	{
		if (!m_trainNetwork.restoreState(meta[U"railway"]))
		{
			DBG_LOG(U"[Load] railway snapshot is invalid");
			return false;
		}
	}
	else { MapGenerator::setupTrain(m_trainNetwork,m_world,m_districts,&m_network); }
	m_districtHierarchy.generate(m_world,m_districts);
	m_network.recomputeAllAutoSigns();
	m_roadRenderer.setMunicipalityLookup([this](Vec2 point)
	{
		const int id=m_districtHierarchy.at(point,0);
		return id>=0 ? m_districtHierarchy.areas[id].name : U"";
	});
	applyZonesGlobal();
	placeInitialBuildings(true);
	const FilePath clearancePath = saveRoot + U"/global/construction_clearance.json";
	if (FileSystem::IsFile(clearancePath) && m_clearanceLedger.load(clearancePath))
		m_clearanceLedger.apply(m_world);
	m_restoreConstructionSites = true;
	registerGuideDestinations();

	m_roadRenderer.invalidateAllCaches();

	m_clock.now   = gameNow;
	m_clock.speed = static_cast<TimeSpeed>(timeScale);
	m_clock.syncCalendar();

	m_camera.setState(Vec3{ focusX, focusY, focusZ }, camDist, camYaw, camPitch);


	m_world.update(m_camera.focusPoint());
	startSimThread();

	Console << U"[Load] finish: {:.0f}ms"_fmt(step.msF());
	m_genProgress.store(1.0f);
	generateLandPatches(true);
	m_clearanceLedger.apply(m_world);
	migrateLegacyBuildingFrontageReferences();
	refreshBuildingAnglesFromEdges();
	if (meta.contains(U"zoneDevelopment")) { m_zoneManager.restoreState(meta[U"zoneDevelopment"],m_world); }
	m_cityConstraintValidationPassed = validateGeneratedCityConstraints();
	Console << U"[Load] TOTAL: {:.0f}ms from {}"_fmt(loadTotal.msF(), saveRoot);
	return true;
}

// =============================================================================
// 地区リスト更新
// =============================================================================

void GameScene::addDistricts(const Array<MapGenerator::Settlement>& newDistricts)
{
	for (auto s : newDistricts)
	{
		if (s.name.isEmpty())
		{
			const int idx = static_cast<int>(m_districts.size());
			s.name    = m_placeNames.settlementName(idx);
			s.reading = m_placeNames.settlementReading(idx);
		}
		m_districts << s;
		if (s.kind == MapGenerator::SettlementKind::RegionalCity)
			m_castleTownCenters << s.center;
	}
}

// =============================================================================
// 初期土地利用の形状補助
// =============================================================================

// ===== 集落生成の呼び出しと、画面へ返す検証結果 =====

SettlementDevelopment GameScene::settlementDevelopment()
{
	return { m_world, m_network, m_trainNetwork, m_districts, getData().seed };
}

void GameScene::applyZonesGlobal()
{
	settlementDevelopment().applyZonesGlobal();
}

void GameScene::placeInitialBuildings(bool preserveLandPatches)
{
	const auto result = settlementDevelopment().placeInitialBuildings(preserveLandPatches);
	m_cityConstraintValidationPassed = result.passed;
	m_cityConstraintValidationSummary = result.summary;
}

void GameScene::generateLandPatches(bool preserveExisting)
{
	settlementDevelopment().generateLandPatches(preserveExisting);
}

void GameScene::migrateLegacyBuildingFrontageReferences()
{
	settlementDevelopment().migrateLegacyBuildingFrontageReferences();
}

bool GameScene::validateGeneratedCityConstraints()
{
	const auto result = settlementDevelopment().validateGeneratedCityConstraints();
	m_cityConstraintValidationSummary = result.summary;
	return result.passed;
}

void GameScene::refreshBuildingAnglesFromEdges()
{
	settlementDevelopment().refreshBuildingAnglesFromEdges();
}

Vec3 GameScene::captureFocusPoint() const
{
	constexpr float cellSize = static_cast<float>(CHUNK_SIZE) / ZONE_CELLS;
	const int cellRadius = static_cast<int>(Ceil(360.0f / cellSize));
	Vec2 bestCenter{ WORLD_SIZE * 0.5f, WORLD_SIZE * 0.5f };
	double bestScore = -Math::Inf;

	for (const auto& settlement : m_districts)
	{
		int buildingCount = 0;
		int commercialCount = 0;
		int arterialNodeCount = 0;
		Point centerChunk;
		int centerCol = 0;
		int centerRow = 0;
		worldToZoneCell(static_cast<float>(settlement.center.x), static_cast<float>(settlement.center.y), centerChunk, centerCol, centerRow);

		for (int dz = -cellRadius; dz <= cellRadius; ++dz)
		{
			for (int dx = -cellRadius; dx <= cellRadius; ++dx)
			{
				int col = centerCol + dx;
				int row = centerRow + dz;
				Point chunkCoord = centerChunk;
				while (col < 0) { col += ZONE_CELLS; --chunkCoord.x; }
				while (col >= ZONE_CELLS) { col -= ZONE_CELLS; ++chunkCoord.x; }
				while (row < 0) { row += ZONE_CELLS; --chunkCoord.y; }
				while (row >= ZONE_CELLS) { row -= ZONE_CELLS; ++chunkCoord.y; }
				const Chunk* chunk = m_world.getChunk(chunkCoord);
				if (!chunk) continue;
				const Building& building = chunk->buildingGrid[{ col, row }];
				if (building.type == BuildingType::None || building.type == BuildingType::Farmland) continue;
				++buildingCount;
				if (building.type == BuildingType::Shop || building.type == BuildingType::Office || building.type == BuildingType::PublicFacility)
				{
					++commercialCount;
				}
			}
		}

		const double radiusSq = 720.0 * 720.0;
		for (const auto& node : m_network.nodes())
		{
			if (node.id < 0) continue;
			const double dx = node.position.x - settlement.center.x;
			const double dz = node.position.z - settlement.center.y;
			if (dx * dx + dz * dz > radiusSq) continue;
			for (const EdgeAttachment& attachment : node.attachments)
			{
				const RoadEdge* edge = m_network.getEdge(attachment.edgeId);
				if (edge && edge->roadType == RoadType::Arterial)
				{
					++arterialNodeCount;
					break;
				}
			}
		}

		const double kindBonus = (settlement.kind == MapGenerator::SettlementKind::RegionalCity) ? 50000.0
			: (settlement.kind == MapGenerator::SettlementKind::LocalTown) ? 28000.0 : 0.0;
		const double score = buildingCount * 1200.0 + commercialCount * 2200.0 + arterialNodeCount * 800.0 + kindBonus;
		if (score > bestScore)
		{
			bestScore = score;
			bestCenter = settlement.center;
		}
	}

	const float y = m_world.computeHeight(static_cast<float>(bestCenter.x), static_cast<float>(bestCenter.y));
	return Vec3{ bestCenter.x, y, bestCenter.y };
}


Vec3 GameScene::captureRuralFringePoint(Vec3 fallback) const
{
	Vec3 best = fallback;
	double bestScore = Math::Inf;
	for (int chunkY = 0; chunkY < WORLD_CHUNKS; ++chunkY)
	{
		for (int chunkX = 0; chunkX < WORLD_CHUNKS; ++chunkX)
		{
			const Chunk* chunk = m_world.getChunk(Point{ chunkX, chunkY });
			if (!chunk) continue;
			for (int row = 1; row < ZONE_CELLS - 1; ++row)
			{
				for (int col = 1; col < ZONE_CELLS - 1; ++col)
				{
					if (chunk->zoneMap[{ col, row }] != ZoneType::Agriculture) continue;

					bool touchesUrban = false;
					for (int dz = -1; dz <= 1 && !touchesUrban; ++dz)
					{
						for (int dx = -1; dx <= 1; ++dx)
						{
							const ZoneType neighbor = chunk->zoneMap[{ col + dx, row + dz }];
							if (neighbor == ZoneType::Commercial || neighbor == ZoneType::Residential
								|| neighbor == ZoneType::LowResidential || neighbor == ZoneType::Industrial)
							{
								touchesUrban = true;
								break;
							}
						}
					}
					if (!touchesUrban) continue;

					const Vec2 center = cellCenterXZ(Point{ chunkX, chunkY }, col, row);
					const double dx = center.x - fallback.x;
					const double dz = center.y - fallback.z;
					const double score = dx * dx + dz * dz;
					if (score < bestScore)
					{
						bestScore = score;
						best = Vec3{ center.x, m_world.computeHeight(static_cast<float>(center.x), static_cast<float>(center.y)), center.y };
					}
				}
			}
		}
	}
	return best;
}
Vec3 GameScene::captureStreetCornerPoint(Vec3 fallback) const
{
	constexpr float cellSize = static_cast<float>(CHUNK_SIZE) / ZONE_CELLS;
	const float radius = 120.0f;
	const float radiusSq = radius * radius;
	const int cellRadius = static_cast<int>(Ceil(radius / cellSize));
	int bestNode = -1;
	double bestScore = -Math::Inf;
	for (const auto& node : m_network.nodes())
	{
		if (node.id < 0 || node.attachments.size() < 3) continue;
		const double fallbackDx = node.position.x - fallback.x;
		const double fallbackDz = node.position.z - fallback.z;
		const double fallbackDistSq = fallbackDx * fallbackDx + fallbackDz * fallbackDz;
		if (fallbackDistSq > 2400.0 * 2400.0) continue;

		int buildingCount = 0;
		int commercialCount = 0;
		int parkingCount = 0;
		int arterialCount = 0;
		for (const EdgeAttachment& attachment : node.attachments)
		{
			const RoadEdge* edge = m_network.getEdge(attachment.edgeId);
			if (edge && edge->roadType == RoadType::Arterial) ++arterialCount;
		}
		for (int dz = -cellRadius; dz <= cellRadius; ++dz)
		{
			for (int dx = -cellRadius; dx <= cellRadius; ++dx)
			{
				const float wx = static_cast<float>(node.position.x) + dx * cellSize;
				const float wz = static_cast<float>(node.position.z) + dz * cellSize;
				Point cc;
				int col = 0, row = 0;
				worldToZoneCell(wx, wz, cc, col, row);
				const Chunk* chunk = m_world.getChunk(cc);
				if (!chunk) continue;
				const Building& building = chunk->buildingGrid[{ col, row }];
				if (building.type == BuildingType::None || building.type == BuildingType::Farmland) continue;
				const Vec2 center = cellCenterXZ(cc, col, row) + Vec2{ building.offsetX, building.offsetZ };
				const float bx = static_cast<float>(center.x - node.position.x);
				const float bz = static_cast<float>(center.y - node.position.z);
				if (bx * bx + bz * bz > radiusSq) continue;
				++buildingCount;
				if (building.type == BuildingType::Shop || building.type == BuildingType::Office
					|| building.type == BuildingType::PublicFacility) ++commercialCount;
				if (building.type == BuildingType::Parking) ++parkingCount;
			}
		}

		const double degreeBonus = Min<double>(static_cast<double>(node.attachments.size()), 4.0) * 9000.0;
		const double score = (buildingCount - commercialCount - parkingCount) * 14500.0 + commercialCount * 1200.0 + parkingCount * 800.0
			+ arterialCount * 3000.0 + degreeBonus - fallbackDistSq * 0.035;
		if (score > bestScore)
		{
			bestScore = score;
			bestNode = node.id;
		}
	}

	if (const RoadNode* node = m_network.getNode(bestNode))
	{
		const float y = m_world.computeHeight(
			static_cast<float>(node->position.x), static_cast<float>(node->position.z));
		return Vec3{ node->position.x, y, node->position.z };
	}
	return fallback;
}
Vec3 GameScene::captureIntersectionPoint(Vec3 fallback, int variant) const
{
	if (getData().captureNode >= 0)
	{
		if (const auto* node = m_network.getNode(getData().captureNode)) { return node->position; }
	}
	if (getData().captureRoadRenders)
	{
		Array<std::pair<double, int>> candidates;
		for (const auto& node : m_network.nodes())
		{
			if (node.id < 0 || node.attachments.size() < 3) { continue; }
			int arterial = 0;
			for (const auto& attachment : node.attachments)
			{
				const auto* edge = m_network.getEdge(attachment.edgeId);
				if (edge && edge->length > 100.0f)
				{
					for (const auto& part : edge->parts)
					{
						if (part.type == RoadPartType::Sidewalk && part.build == BuildState::Built) { ++arterial; break; }
					}
				}
			}
			if (arterial < 2) { continue; }
			const double score = node.position.distanceFromSq(fallback) + (node.attachments.size() == 3 ? 0.0 : 1e10);
			candidates << std::pair<double, int>{ score, node.id };
		}
		candidates.sort_by([](const auto& a, const auto& b) { return a.first < b.first; });
		if (!candidates.isEmpty())
		{
			const auto* node = m_network.getNode(candidates[Min(static_cast<size_t>(variant), candidates.size()-1)].second);
			const double y = m_world.computeHeight(static_cast<float>(node->position.x), static_cast<float>(node->position.z));
			if (variant == m_captureIndex / 2)
			{
				DebugLog::print(U"[RoadCapture] view={} node={} attachments={} position=({:.2f},{:.2f},{:.2f})"_fmt(m_captureIndex, node->id, node->attachments.size(), node->position.x, y, node->position.z));
			}
			return Vec3{ node->position.x, y, node->position.z };
		}
	}

	constexpr float cellSize = static_cast<float>(CHUNK_SIZE) / ZONE_CELLS;
	const float radius = 130.0f;
	const float radiusSq = radius * radius;
	const int cellRadius = static_cast<int>(Ceil(radius / cellSize));
	struct CaptureIntersectionCandidate
	{
		int nodeId = -1;
		double score = 0.0;
	};
	Array<CaptureIntersectionCandidate> candidates;
	for (const auto& node : m_network.nodes())
	{
		if (node.id < 0 || node.attachments.size() < 3) continue;
		const double fallbackDx = node.position.x - fallback.x;
		const double fallbackDz = node.position.z - fallback.z;
		const double fallbackDistSq = fallbackDx * fallbackDx + fallbackDz * fallbackDz;
		if (fallbackDistSq > 2600.0 * 2600.0) continue;

		int arterialCount = 0;
		int localCount = 0;
		for (const EdgeAttachment& attachment : node.attachments)
		{
			const RoadEdge* edge = m_network.getEdge(attachment.edgeId);
			if (!edge) continue;
			if (edge->roadType == RoadType::Arterial) ++arterialCount;
			else if (edge->roadType == RoadType::LocalRoad) ++localCount;
		}

		int buildingCount = 0;
		int commercialCount = 0;
		for (int dz = -cellRadius; dz <= cellRadius; ++dz)
		{
			for (int dx = -cellRadius; dx <= cellRadius; ++dx)
			{
				const float wx = static_cast<float>(node.position.x) + dx * cellSize;
				const float wz = static_cast<float>(node.position.z) + dz * cellSize;
				Point cc;
				int col = 0, row = 0;
				worldToZoneCell(wx, wz, cc, col, row);
				const Chunk* chunk = m_world.getChunk(cc);
				if (!chunk) continue;
				const Building& building = chunk->buildingGrid[{ col, row }];
				if (building.type == BuildingType::None || building.type == BuildingType::Farmland) continue;
				const Vec2 center = cellCenterXZ(cc, col, row) + Vec2{ building.offsetX, building.offsetZ };
				const float bx = static_cast<float>(center.x - node.position.x);
				const float bz = static_cast<float>(center.y - node.position.z);
				if (bx * bx + bz * bz > radiusSq) continue;
				++buildingCount;
				if (building.type == BuildingType::Shop || building.type == BuildingType::Office
					|| building.type == BuildingType::PublicFacility) ++commercialCount;
			}
		}

		if (arterialCount <= 0) continue;
		const double hierarchyBonus = (arterialCount > 0 && localCount > 0) ? 140000.0 : (arterialCount > 1 ? 90000.0 : 0.0);
		const double degreeBonus = Min<double>(static_cast<double>(node.attachments.size()), 4.0) * 12000.0;
		const double score = hierarchyBonus + arterialCount * 26000.0 + localCount * 9000.0
			+ buildingCount * 6200.0 + commercialCount * 4200.0 + degreeBonus - fallbackDistSq * 0.020;
		candidates << CaptureIntersectionCandidate{ node.id, score };
	}
	candidates.sort_by([](const CaptureIntersectionCandidate& a, const CaptureIntersectionCandidate& b)
	{
		return a.score > b.score;
	});

	Array<Vec2> accepted;
	int acceptedIndex = 0;
	for (const CaptureIntersectionCandidate& candidate : candidates)
	{
		const RoadNode* node = m_network.getNode(candidate.nodeId);
		if (!node) continue;
		const Vec2 pos{ node->position.x, node->position.z };
		bool tooClose = false;
		for (const Vec2& other : accepted)
		{
			if ((pos - other).lengthSq() < 150.0 * 150.0)
			{
				tooClose = true;
				break;
			}
		}
		if (tooClose) continue;
		accepted << pos;
		if (acceptedIndex == variant)
		{
			const float y = m_world.computeHeight(static_cast<float>(node->position.x), static_cast<float>(node->position.z));
			return Vec3{ node->position.x, y, node->position.z };
		}
		++acceptedIndex;
	}
	return captureStreetCornerPoint(fallback);
}

Vec3 GameScene::captureCoastalBufferPoint(Vec3 fallback) const
{
	Vec3 best = fallback;
	double bestScore = Math::Inf;
	for (int chunkY = 0; chunkY < WORLD_CHUNKS; ++chunkY)
	{
		for (int chunkX = 0; chunkX < WORLD_CHUNKS; ++chunkX)
		{
			const Chunk* chunk = m_world.getChunk(Point{ chunkX, chunkY });
			if (!chunk) continue;
			for (const LandPatch& patch : chunk->landPatches)
			{
				if (patch.type != LandPatchType::Beach && patch.type != LandPatchType::Seawall) continue;
				if (patch.polygon.isEmpty()) continue;
				Vec2 center{ 0.0, 0.0 };
				for (const Vec2& p : patch.polygon) center += p;
				center /= static_cast<double>(patch.polygon.size());
				const double dx = center.x - fallback.x;
				const double dz = center.y - fallback.z;
				const double distSq = dx * dx + dz * dz;
				const double typeBonus = (patch.type == LandPatchType::Seawall) ? -220000.0 : 0.0;
				const double score = distSq + typeBonus;
				if (score < bestScore)
				{
					bestScore = score;
					best = Vec3{ center.x, m_world.computeHeight(static_cast<float>(center.x), static_cast<float>(center.y)), center.y };
				}
			}
		}
	}
	return best;
}
String GameScene::captureFileName(int index) const
{
	switch (index)
	{
	case 0: return U"city_render_01_overall.png";
	case 1: return U"city_render_02_city.png";
	case 2: return U"city_render_03_close.png";
	case 3: return U"city_render_04_rural_fringe.png";
	case 4: return U"city_render_05_intersection_overview.png";
	case 5: return U"city_render_06_intersection_zoom_a.png";
	case 6: return U"city_render_07_intersection_zoom_b.png";
	case 7: return U"city_render_08_intersection_zoom_c.png";
	case 8: return U"city_render_09_intersection_zoom_d.png";
	case 9: return U"city_render_10_intersection_topdown_a.png";
	case 10: return U"city_render_11_intersection_topdown_b.png";
	case 11: return U"city_render_12_intersection_zoom_e.png";
	case 12: return U"city_render_13_intersection_zoom_f.png";
	case 13: return U"city_render_14_intersection_marking_low_a.png";
	case 14: return U"city_render_15_intersection_marking_low_b.png";
	case 15: return U"city_render_16_intersection_marking_low_c.png";
	case 16: return U"city_render_17_intersection_topdown_c.png";
	case 17: return U"city_render_18_intersection_topdown_d.png";
	case 18: return U"city_render_19_intersection_topdown_e.png";
	case 19: return U"city_render_20_street_corner.png";
	case 20: return U"city_render_21_coastal_buffer.png";
	case 21: return U"city_render_22_rural_landuse.png";
	case 22: return U"city_render_23_traffic.png";
	case 23: return U"city_render_24_traffic_close.png";
	case 24: return U"city_render_25_satoyama.png";
	case 25: return U"city_render_26_provincial_town.png";
	case 26: return U"city_render_27_castle_transition.png";
	case 27: return U"city_render_28_fringe_streets.png";
	case 28: return U"city_render_29_field_access.png";
	case 29: return U"city_render_30_farm_track_walk.png";
	case 30: return U"city_render_31_urban_convenience.png";
	case 31: return U"city_render_32_roadside_convenience.png";
	case 32: return U"city_render_33_urban_fuel.png";
	case 33: return U"city_render_34_roadside_fuel.png";
	case 34: return U"city_render_35_rural_house.png";
	default: return U"city_render_done.png";
	}
}
void GameScene::updateStreamingBenchmark()
{
	m_clock.speed = TimeSpeed::Paused;
	m_clock.hour = 13.0f;
	m_camera.setBlockInput(true);
	if (!m_benchmarkOrigin) { m_benchmarkOrigin = captureFocusPoint(); }
	const Vec3 origin = *m_benchmarkOrigin;
	const int flightFrame = Max(0, m_captureFrame - 120);
	Vec3 focus = origin + Vec3{flightFrame * 5.0, 0, Sin(flightFrame * 0.005) * 500.0};
	focus.y = m_world.computeHeight(static_cast<float>(focus.x), static_cast<float>(focus.z));
	m_camera.setCaptureState(focus, 650.0f, static_cast<float>(-45.0_deg), static_cast<float>(48.0_deg));
	const Stopwatch timer{StartImmediately::Yes};
	m_world.update(focus);
	renderWorld();
	if (Scene::FrameCount() % 120 == 0)
	{
		DBG_LOG(U"[StreamingProgress] frame={} pending={} signalsMs={:.3f}"_fmt(
			m_captureFrame, m_worldRenderer.pendingTerrainJobs(), m_renderTimings.signals));
	}
	if (m_captureFrame == 60 && m_worldRenderer.pendingTerrainJobs() > 0) { return; }
	if (m_captureFrame >= 120)
	{
		const double cpuMs = timer.msF();
		m_captureCpuTimes << cpuMs;
		m_captureFrameTimes << Scene::DeltaTime() * 1000.0;
		if (cpuMs > 40.0)
		{
			DebugLog::print(U"[FlightSpike] frame={} cpuMs={:.2f} terrainMs={:.2f} roadsMs={:.2f} shadowMs={:.2f} hudMs={:.2f}"_fmt(
				flightFrame, cpuMs, m_renderTimings.terrainOnly, m_renderTimings.roadMesh, m_cityLighting.shadowMilliseconds(),m_renderTimings.uiRenderer));
		}
	}
	if (++m_captureFrame >= 840)
	{
		TextWriter csv{U"streaming_frames.csv"};
		csv.writeln(U"frame,cpuMs,frameMs");
		for (size_t i = 0; i < m_captureCpuTimes.size(); ++i)
		{
			csv.writeln(U"{},{:.3f},{:.3f}"_fmt(i,m_captureCpuTimes[i],m_captureFrameTimes[i]));
		}
		DebugLog::print(U"[StreamingBenchmark] complete sync={} frames={}"_fmt(getData().syncTerrain,m_captureCpuTimes.size()));
		System::Exit();
	}
}

void GameScene::updateCaptureCityRenders()
{
	const int kCaptureCount = getData().captureRoadRenders ? 6 : 35;
	const int warmupFrames = m_captureIndex == 22 ? 240 : 80;

	m_clock.speed = TimeSpeed::Paused;
	m_clock.hour = 13.0f;
	m_camera.setBlockInput(true);

	if (m_captureCameraDirty)
	{
		if (getData().captureRoadRenders && m_captureIndex == 0)
		{
			int checked = 0, repaired = 0, missing = 0;
			for (const auto& node : m_network.nodes())
			{
				if (node.id < 0 || node.attachments.size() < 2) { continue; }
				bool needsCap = false;
				int builtApproaches = 0;
				for (const auto& attachment : node.attachments)
				{
					const auto* edge = m_network.getEdge(attachment.edgeId);
					if (!edge || !edge->isRoadbedBuilt() || (edge->edgeState != EdgeState::Open && edge->edgeState != EdgeState::Existing)) { continue; }
					++builtApproaches;
					needsCap = needsCap || ((edge->nodeA == node.id ? edge->cutoffA : edge->cutoffB) > 0.15f);
				}
				if (builtApproaches < 2 || !needsCap) { continue; }
				++checked;
				const auto layout = JunctionGeometry::build(m_network,node.id);
				repaired += layout.repaired;
				if (layout.asphalt.indices.isEmpty()) { ++missing; DebugLog::print(U"[JunctionAudit] missing node={}"_fmt(node.id)); }
			}
			DebugLog::print(U"[JunctionAudit] checked={} repaired={} missing={}"_fmt(checked,repaired,missing));
		}
		const Vec3 focus = captureFocusPoint();
		const Vec3 streetFocus = captureStreetCornerPoint(focus);
		const Vec3 intersectionA = captureIntersectionPoint(focus, 0);
		const Vec3 intersectionB = captureIntersectionPoint(focus, 1);
		const Vec3 intersectionC = captureIntersectionPoint(focus, 2);
		const Vec3 intersectionD = captureIntersectionPoint(focus, 3);
		const Vec3 intersectionE = captureIntersectionPoint(focus, 4);
		const Vec3 intersectionF = captureIntersectionPoint(focus, 5);
		const Vec3 fringeFocus = captureRuralFringePoint(focus);
		const Vec3 coastalFocus = captureCoastalBufferPoint(focus);
		if (getData().captureRoadRenders)
		{
			const Vec3 roadFocus = captureIntersectionPoint(focus, m_captureIndex / 2);
			const bool overhead = (m_captureIndex % 2) != 0;
			m_camera.setCaptureState(roadFocus, overhead ? 165.0f : 125.0f,
				static_cast<float>(-40.0_deg), overhead ? static_cast<float>(86.0_deg) : static_cast<float>(43.0_deg));
		}
		else
		switch (m_captureIndex)
		{
		case 0:
			m_camera.setCaptureState(focus, 1800.0f, static_cast<float>(-39.0_deg), static_cast<float>(58.0_deg));
			break;
		case 1:
			m_camera.setCaptureState(focus + Vec3{ 120.0, 0.0, -60.0 }, 820.0f, static_cast<float>(-45.0_deg), static_cast<float>(43.0_deg));
			break;
		case 2:
			m_camera.setCaptureState(streetFocus + Vec3{ 34.0, 0.0, -24.0 }, 230.0f, static_cast<float>(-50.0_deg), static_cast<float>(30.0_deg));
			break;
		case 3:
			m_camera.setCaptureState(fringeFocus + Vec3{ 70.0, 0.0, -58.0 }, 680.0f, static_cast<float>(-45.0_deg), static_cast<float>(48.0_deg));
			break;
		case 4:
			m_camera.setCaptureState(intersectionA + Vec3{ 24.0, 0.0, -18.0 }, 260.0f, static_cast<float>(-45.0_deg), static_cast<float>(48.0_deg));
			break;
		case 5:
			m_camera.setCaptureState(intersectionA + Vec3{ 18.0, 0.0, -14.0 }, 150.0f, static_cast<float>(-44.0_deg), static_cast<float>(42.0_deg));
			break;
		case 6:
			m_camera.setCaptureState(intersectionB + Vec3{ -28.0, 0.0, 22.0 }, 170.0f, static_cast<float>(-32.0_deg), static_cast<float>(44.0_deg));
			break;
		case 7:
			m_camera.setCaptureState(intersectionC + Vec3{ 28.0, 0.0, 18.0 }, 180.0f, static_cast<float>(-58.0_deg), static_cast<float>(42.0_deg));
			break;
		case 8:
			m_camera.setCaptureState(intersectionD + Vec3{ -18.0, 0.0, -26.0 }, 135.0f, static_cast<float>(34.0_deg), static_cast<float>(40.0_deg));
			break;
		case 9:
			m_camera.setCaptureState(intersectionA, 210.0f, static_cast<float>(0.0_deg), static_cast<float>(86.0_deg));
			break;
		case 10:
			m_camera.setCaptureState(intersectionB, 230.0f, static_cast<float>(90.0_deg), static_cast<float>(84.0_deg));
			break;
		case 11:
			m_camera.setCaptureState(intersectionE + Vec3{ 20.0, 0.0, 24.0 }, 140.0f, static_cast<float>(68.0_deg), static_cast<float>(43.0_deg));
			break;
		case 12:
			m_camera.setCaptureState(intersectionF + Vec3{ -22.0, 0.0, -18.0 }, 125.0f, static_cast<float>(-118.0_deg), static_cast<float>(41.0_deg));
			break;
		case 13:
			m_camera.setCaptureState(intersectionA + Vec3{ 9.0, 0.0, -7.0 }, 78.0f, static_cast<float>(-42.0_deg), static_cast<float>(31.0_deg));
			break;
		case 14:
			m_camera.setCaptureState(intersectionB + Vec3{ -9.0, 0.0, 9.0 }, 82.0f, static_cast<float>(132.0_deg), static_cast<float>(32.0_deg));
			break;
		case 15:
			m_camera.setCaptureState(intersectionC + Vec3{ 11.0, 0.0, 8.0 }, 86.0f, static_cast<float>(38.0_deg), static_cast<float>(33.0_deg));
			break;
		case 16:
			m_camera.setCaptureState(intersectionC, 190.0f, static_cast<float>(180.0_deg), static_cast<float>(86.0_deg));
			break;
		case 17:
			m_camera.setCaptureState(intersectionD, 185.0f, static_cast<float>(270.0_deg), static_cast<float>(86.0_deg));
			break;
		case 18:
			m_camera.setCaptureState(intersectionE, 170.0f, static_cast<float>(45.0_deg), static_cast<float>(86.0_deg));
			break;
		case 19:
			m_camera.setCaptureState(streetFocus + Vec3{ 26.0, 0.0, -20.0 }, 115.0f, static_cast<float>(27.0_deg), static_cast<float>(54.0_deg));
			break;
		case 20:
			m_camera.setCaptureState(coastalFocus + Vec3{ 62.0, 0.0, -42.0 }, 260.0f, static_cast<float>(38.0_deg), static_cast<float>(43.0_deg));
			break;
		case 22:
		{
			m_camera.setCaptureState(streetFocus, 300.0f, static_cast<float>(-50.0_deg), static_cast<float>(40.0_deg));
			Array<std::pair<double, int>> candidates;
			for (const auto& edge : m_network.edges())
			{
				if (!edge.isRoadbedBuilt() || edge.length < 25 || !m_simGraph->getEdge(edge.id)) { continue; }
				const auto bezier = m_network.getBezier(edge.id);
				if (!bezier) { continue; }
				const double distance = bezier->positionAt(bezier->totalLength * 0.5f).distanceFrom(streetFocus);
				if (distance < 400) { candidates.emplace_back(distance, edge.id); }
			}
			candidates.sort();
			Reseed(getData().seed);
			for (size_t index = 0; index < Min(size_t{ 200 }, candidates.size()); ++index)
			{
				const VehicleType type = index % 3 == 0 ? VehicleType::KeiCar : VehicleType::PassengerCar;
				m_vehicleManager.spawnOnEdge(candidates[index].second, *m_simGraph, type,
					candidates[(index + candidates.size() / 2) % candidates.size()].second);
			}
			DebugLog::print(U"[TrafficCapture] spawned={} candidates={}"_fmt(m_vehicleManager.vehicles().size(), candidates.size()));
			break;
		}
		case 23:
		{
			Vec3 trafficFocus = streetFocus;
			double nearest = Math::Inf;
			for (const Vehicle& vehicle : m_renderVehicles)
			{
				const double distance = vehicle.position.distanceFrom(streetFocus);
				if (vehicle.speed > 1.0f && distance < nearest) { trafficFocus = vehicle.position; nearest = distance; }
			}
			m_camera.setCaptureState(trafficFocus, 70.0f, static_cast<float>(-38.0_deg), static_cast<float>(45.0_deg));
			break;
		}
		case 24:
		{
			Vec3 woodland = fringeFocus;
			double best = Math::Inf;
			for (int z = 1; z < WORLD_CHUNKS; ++z) for (int x = 1; x < WORLD_CHUNKS; ++x)
			{
				const Chunk* chunk = m_world.getChunk(Point{x,z});
				if (!chunk) { continue; }
				for (int row = 8; row < ZONE_CELLS; row += 8) for (int col = 8; col < ZONE_CELLS; col += 8)
				{
					if (chunk->zoneMap[{col,row}] != ZoneType::Unzoned) { continue; }
					const Vec3 point{x*CHUNK_SIZE+col*16.0,chunk->heightMap[{col,row}],z*CHUNK_SIZE+row*16.0};
					if (point.y < 45 || point.y > 180) { continue; }
					const double score = point.distanceFromSq(fringeFocus);
					if (score < best) { woodland = point; best = score; }
				}
			}
			m_camera.setCaptureState(woodland,1000.0f,static_cast<float>(-55.0_deg),static_cast<float>(36.0_deg));
			DebugLog::print(U"[PhotoReferenceCapture] satoyama=({:.1f},{:.1f},{:.1f})"_fmt(woodland.x,woodland.y,woodland.z));
			break;
		}
		case 25:
		{
			Vec3 provincial = fringeFocus;
			for (const auto& settlement : m_districts)
			{
				if (settlement.kind != MapGenerator::SettlementKind::LocalTown) { continue; }
				provincial = Vec3{settlement.center.x,m_world.computeHeight(static_cast<float>(settlement.center.x),static_cast<float>(settlement.center.y)),settlement.center.y};
				break;
			}
			m_camera.setCaptureState(provincial,300.0f,static_cast<float>(-40.0_deg),static_cast<float>(35.0_deg));
			break;
		}
		case 30: case 31: case 32: case 33: case 34:
			prepareRoadsideCapture(m_captureIndex-30);
			break;
		case 26: case 27: case 28: case 29:
			prepareFringeCapture(m_captureIndex-26);
			break;
		case 21:
			m_camera.setCaptureState(fringeFocus + Vec3{ -80.0, 0.0, 70.0 }, 520.0f, static_cast<float>(128.0_deg), static_cast<float>(50.0_deg));
			break;
		}
		m_captureCameraDirty = false;
		m_captureFrameTimes.clear();
		m_captureCpuTimes.clear();
		m_captureGpuTimes.clear();
		m_captureFrame = 0;
	}

	m_world.update(m_camera.focusPoint());
	if (!getData().captureRoadRenders && m_simGraph)
	{
		for (auto& response : m_simThread.drainResponses())
		{
			if (const auto* route = std::get_if<RouteResponse>(&response)) { m_vehicleManager.applyRouteResponse(*route); }
		}
		constexpr double kCaptureTimeStep = 1.0 / 60.0;
		m_clock.now += kCaptureTimeStep;
		m_vehicleManager.setTrafficDemand(calculateTrafficDemand(m_economy.population, m_citySnapshot, m_clock.hour));
		m_vehicleManager.setTrafficFocus(m_camera.focusPoint());
		m_trainManager.update(kCaptureTimeStep,m_clock.now);
		m_vehicleManager.update(kCaptureTimeStep, m_clock.now, *m_simGraph, m_network, m_roadRenderer.visibleEdges());
		for (auto& request : m_vehicleManager.collectRequests()) { m_simThread.pushRequest(std::move(request)); }
	}
	renderWorld();
	if (m_captureIndex == 22 && m_captureFrame == 20)
	{
		for (const Vehicle& vehicle : m_renderVehicles) { m_captureVehicleStartPositions[vehicle.id] = vehicle.position; }
	}

	if (m_captureFrame >= warmupFrames - 60 && m_captureFrame < warmupFrames)
	{
		m_captureFrameTimes << Scene::DeltaTime() * 1000.0;
		m_captureCpuTimes << m_renderTimings.total;
		if (m_gpuTimer.milliseconds() >= 0.0)
		{
			m_captureGpuTimes << m_gpuTimer.milliseconds();
		}
	}
	// Only sample settled geometry; async terrain must finish before the final 60 frames.
	if (m_captureFrame == warmupFrames - 61 && m_worldRenderer.pendingTerrainJobs() > 0) { return; }
	if (++m_captureFrame == warmupFrames)
	{
		FileSystem::CreateDirectories(U"Screenshot/city_generation");
		const String fileName = U"city_generation/" + captureFileName(m_captureIndex);
		ScreenCapture::SaveCurrentFrame(fileName);
		DebugLog::print(U"[CapturePerf] view={} frameMs={:.2f} cpuMs={:.2f} terrainMs={:.2f} roadsMs={:.2f} shadowMs={:.2f}"_fmt(
			m_captureIndex, Scene::DeltaTime() * 1000.0, m_renderTimings.total,
			m_renderTimings.terrainOnly, m_renderTimings.roadMesh, m_cityLighting.shadowMilliseconds()));
		auto percentile = [](Array<double> values, double fraction)
		{
			if (values.isEmpty()) { return -1.0; }
			values.sort();
			return values[Min(values.size() - 1, static_cast<size_t>(fraction * (values.size() - 1)))];
		};
		DebugLog::print(U"[CaptureDistribution] view={} samples={} frameP50={:.2f} frameP95={:.2f} cpuP50={:.2f} gpuForwardP50={:.2f} gpuForwardP95={:.2f}"_fmt(
			m_captureIndex, m_captureFrameTimes.size(), percentile(m_captureFrameTimes, 0.5),
			percentile(m_captureFrameTimes, 0.95), percentile(m_captureCpuTimes, 0.5),
			percentile(m_captureGpuTimes, 0.5), percentile(m_captureGpuTimes, 0.95)));
		DebugLog::print(U"[BuildingVisibility] submitted={} considered={}"_fmt(
			m_worldRenderer.buildingsSubmitted(), m_worldRenderer.buildingsConsidered()));
		if (!getData().captureRoadRenders && m_simGraph)
		{
			int moving = 0;
			double totalDistance = 0;
			for (const Vehicle& vehicle : m_renderVehicles)
			{
				const auto start = m_captureVehicleStartPositions.find(vehicle.id);
				if (start != m_captureVehicleStartPositions.end())
				{
					const double distance = vehicle.position.distanceFrom(start->second);
					if (distance > 1) { ++moving; totalDistance += distance; }
				}
			}
			DebugLog::print(U"[TrafficCapture] total={} active={} moved={} meanDistanceM={:.2f}"_fmt(
				m_vehicleManager.vehicles().size(), m_renderVehicles.size(), moving, totalDistance / Max(1, moving)));
		}
		DebugLog::print(U"[CaptureCity] saved Screenshot/{}"_fmt(fileName));
	}
	else if (m_captureFrame > warmupFrames + 8)
	{
		++m_captureIndex;
		if (m_captureIndex >= kCaptureCount)
		{
			{
				TextWriter writer{ U"Screenshot/city_generation/validation_report.txt" };
				if (writer)
				{
					writer << U"passed=" + String{ m_cityConstraintValidationPassed ? U"true" : U"false" };
					writer << U"\n";
					writer << m_cityConstraintValidationSummary;
				}
			}
			if (!m_cityConstraintValidationPassed)
			{
				TextWriter writer{ U"Screenshot/city_generation/constraint_validation_failed.txt" };
				if (writer) writer << U"City constraint validation failed: " + m_cityConstraintValidationSummary;
			}
			System::Exit();
			return;
		}
		m_captureCameraDirty = true;
		m_captureFrame = 0;
	}
}
// =============================================================================
// 毎フレーム更新
// =============================================================================

void GameScene::update()
{
	m_frameRateGraph.sampleNow();
	// シミュレーション応答、時間進行、入力、カメラ、描画準備を毎フレームここで順に同期させる。
	if (m_phase == GamePhase::Loading)
	{
		updateLoading();
		return;
	}

	if (m_restoreConstructionSites)
	{
		m_restoreConstructionSites = false;
		Array<int> edgeIds;
		for (const auto& edge : m_network.edges())
			if (edge.id >= 0 && edge.edgeState == EdgeState::UnderConstruction) edgeIds << edge.id;
		prepareConstructionSite(edgeIds);
	}
	if (getData().inspectNode >= 0)
	{
		if (const auto* node = m_network.getNode(getData().inspectNode))
		{
			Vec3 focus = node->position;
			focus.y = m_world.computeHeight(static_cast<float>(focus.x),static_cast<float>(focus.z));
			m_camera.setCaptureState(focus,125.0f,static_cast<float>(-40.0_deg),static_cast<float>(43.0_deg));
			m_clock.speed = TimeSpeed::Paused;
			m_clock.hour = 13.0f;
			m_world.update(focus);
		}
		getData().inspectNode = -1;
	}

	if (getData().auditRoadIntegrity)
	{
		const auto result = writeGameSnapshot(U"road_integrity_snapshot");
		DBG_LOG(U"[RoadIntegrityAudit] snapshot success={} path={}"_fmt(result.success,result.path));
		System::Exit();
		return;
	}
	if (getData().captureFirstPerson) { updateStreetReview(); return; }
	if (getData().captureTransportObjects) { updateTransportObjectsReview(); return; }
	if (getData().captureTransport) { updateTransportReview(); return; }
	if (getData().captureConstruction)
	{
		updateConstructionReview();
		return;
	}
	if (getData().captureRoadPlanUx)
	{
		updateRoadPlanReview();
		return;
	}

	if (getData().benchmarkNavigation) { updateNavigationBenchmark(); return; }
	if (getData().benchmarkStreaming)
	{
		updateStreamingBenchmark();
		return;
	}
	if (getData().captureCityRenders)
	{
		updateCaptureCityRenders();
		return;
	}

	const double dt = Scene::DeltaTime();
	m_soundEffects.setVolume(getData().effectVolume);
	m_lockWaitMs = 0.0;

	// Sim レスポンスを処理
	for (auto& resp : m_simThread.drainResponses())
	{
		std::visit([&](auto& r)
		{
			using T = std::decay_t<decltype(r)>;
			if constexpr (std::is_same_v<T, RouteResponse>)
				m_vehicleManager.applyRouteResponse(r);
			else if constexpr (std::is_same_v<T, PerfUpdate>)
				m_simPerfHistory.push(r.stats);
		}, resp);
	}

	// ゲーム時計を進める
	if (m_clock.speed != TimeSpeed::Paused)
	{
		const int64 monthIndexBefore = m_clock.monthIndex();
		const double simulationDt = dt * m_clock.speedMultiplier();
		m_clock.advance(dt);
		const int64 monthIndexAfter = m_clock.monthIndex();

		if (monthIndexAfter > monthIndexBefore)
		{
			for (int64 monthIndex = monthIndexBefore + 1; monthIndex <= monthIndexAfter; ++monthIndex)
			{
				const GameTime monthStartTime = GameClock::TimeFromMonthIndex(monthIndex);
				const uint8 month = GameClock::MonthFromMonthIndex(monthIndex);
				m_eventSystem.rollMonthly(monthStartTime, month, monthIndex, m_network);
				m_citySnapshot = collectCitySnapshot(m_world, m_network,
					m_vehicleManager.vehicles(), m_vehicleManager.completedTripMinutes());
				m_lastMonthlyEconomy = m_economy.applyMonthly(m_network, m_citySnapshot,
					m_busSystem.activeRouteCount());
			}
		}

		if (m_simGraph)
		{
			m_vehicleManager.setTrafficDemand(calculateTrafficDemand(m_economy.population, m_citySnapshot, m_clock.hour));
			m_vehicleManager.setTrafficFocus(m_camera.focusPoint());
			m_vehicleManager.update(simulationDt, m_clock.now, *m_simGraph,
			                        m_network, m_roadRenderer.visibleEdges());
		}

		m_trainManager.update(simulationDt, m_clock.now);
		m_eventSystem.update(m_clock.now);
		for (auto& event : m_eventSystem.popNewNotifications())
		{
			m_notifications << std::move(event);
		}
		while (m_notifications.size() > 5)
		{
			m_notifications.erase(m_notifications.begin());
		}
		tickConstruction();
		updateZoneDevelopment(simulationDt);
	}

	// 経路リクエストはゲーム内時間停止中でも送信する
	for (auto& req : m_vehicleManager.collectRequests())
		m_simThread.pushRequest(std::move(req));

	// メインスレッドのロジック
	const Stopwatch swLogic{ StartImmediately::Yes };
	m_world.update(m_camera.focusPoint());
	if (m_selectedLandParcel && !m_panelManager.isVisible(U"land_info")) { clearSelection(); }
	if (m_mode==EditMode::ZonePaint && !m_panelManager.isVisible(U"zone_palette")) { setZonePaintMode(false); }
	if (m_mode!=EditMode::ZonePaint && m_panelManager.isVisible(U"zone_palette")) { setZonePaintMode(false); }
	m_minimapRenderer.setSmallBounds(m_uiRenderer.minimapBounds());
	handleGlobalShortcuts();
	if (!m_showPauseMenu && (!GameInput::keyboardBlocked()))
	{
		if (const auto target=m_minimapRenderer.update(m_camera,m_network,m_trainNetwork,m_districts))
		{
			jumpToMapPosition(*target);
		}
	}
	if (m_railTimetableWasVisible && !m_panelManager.isVisible(U"rail_timetable"))
	{
		GameInput::releaseTextFocus(); m_railTimetableWasVisible = false;
	}
	const bool mapInput=m_minimapRenderer.consumedInput();
	if (!m_showPauseMenu && !mapInput)
		m_panelManager.handleInput();
	m_uiRenderer.updateLayout(m_hudStats);
	if (!m_showPauseMenu && !mapInput && !m_panelManager.blocksMouseInput()) { m_uiRenderer.handleInput(); }
	m_uiRenderer.updateLayout(m_hudStats);
	m_minimapRenderer.setSmallBounds(m_uiRenderer.minimapBounds());
	if (!m_commandPalette.visible && MouseL.down() && GameInput::textInput) { GameInput::releaseTextFocus(); }
	if (MouseL.down() && m_panelManager.isMouseOnAnyPanel()) { GameInput::textOwnedFrame = true; }
	const bool textFocused=GameInput::keyboardBlocked();
	const bool commandChord=GameInput::pressed(KeyControl) &&
		(GameInput::pressed(KeyShift) || GameInput::pressed(KeyZ) || GameInput::pressed(KeyY) || GameInput::pressed(KeyR));
	m_camera.setKeyboardBlocked(mapInput || m_showPauseMenu || textFocused || commandChord);
	m_camera.setBlockInput(mapInput || m_showPauseMenu || textFocused || m_panelManager.isMouseOnAnyPanel() || m_uiRenderer.isMouseOnHud());
	if (!mapInput) { m_camera.update(dt, m_world); }
	m_logicMs = swLogic.msF();

	// 車両追跡
	if (!mapInput && m_trackingVehicle && m_selectedVehicleId)
	{
		if (GameInput::pressed(KeyW) || GameInput::pressed(KeyA) || GameInput::pressed(KeyS) || GameInput::pressed(KeyD))
		{
			m_trackingVehicle = false;
		}
		else
		{
			for (const auto& rv : m_renderVehicles)
			{
				if (rv.id == *m_selectedVehicleId)
				{
					m_camera.setFocus(rv.position);
					break;
				}
			}
		}
	}

	if (m_selectedVehicleId && !m_panelManager.isVisible(U"vehicle_info"))
	{
		m_selectedVehicleId = none;
		m_trackingVehicle = false;
	}

	if (!mapInput)
	{
		if (!m_driving.active()) { updateCursor(); }
		handleInput();
		if (!m_driving.active()) { m_debugRenderer.handleInput(); }
	}
	updateDriving(dt,mapInput);

	if (getData().playtest && !getData().playtestCommands.isEmpty() && m_playtestFrame%15==0) { processPlaytestCommand(); }
	renderWorld();
	if (getData().playtest) { recordPlaytestFrame(); }
}
void GameScene::jumpToMapPosition(Vec2 target)
{
	leaveDriving(true);
	m_trackingVehicle=false;
	target.x=Clamp(target.x,.5,static_cast<double>(WORLD_SIZE)-.5); target.y=Clamp(target.y,.5,static_cast<double>(WORLD_SIZE)-.5);
	m_camera.setFocus({target.x,m_world.sampleHeight(static_cast<float>(target.x),static_cast<float>(target.y)),target.y});
}

void GameScene::updateTransportReview()
{
	m_clock.speed=TimeSpeed::Paused; m_clock.hour=13;
	if (m_captureCameraDirty)
	{
		const Vec3 focus=captureFocusPoint();
		if (m_captureIndex==0) { m_camera.setCaptureState(focus,850,static_cast<float>(-35_deg),static_cast<float>(68_deg)); }
		if (m_captureIndex==1) { m_camera.setCaptureState(captureStreetCornerPoint(focus),100,static_cast<float>(-40_deg),static_cast<float>(32_deg)); }
		if (m_captureIndex==2 && !m_trainNetwork.nodes().isEmpty()) { m_camera.setCaptureState(m_trainNetwork.nodes().front().position,220,static_cast<float>(-50_deg),static_cast<float>(32_deg)); }
		if (m_captureIndex==3)
		{
			for (const auto& edge : m_network.edges())
			{
				if (edge.id<0 || !edge.useElevation) { continue; }
				const Vec3 point=m_network.getBezier(edge.id)->evaluate(.5f);
				if (m_world.sampleHeight(static_cast<float>(point.x),static_cast<float>(point.z))<-1)
				{
					m_camera.setCaptureState(point,200,static_cast<float>(-40_deg),static_cast<float>(42_deg)); break;
				}
			}
		}
		if (m_captureIndex==4) { m_minimapRenderer.openFullScreen(m_camera,m_network,m_trainNetwork,m_districts); }
		if (m_captureIndex==5)
		{
			auto& view=m_minimapRenderer.mapView(); view.center={focus.x,focus.z};
			view.zoomAt(view.body(Scene::Size()).center(),32,Scene::Size());
			view.showContext(view.body(Scene::Size()).center()+Vec2{80,60},Scene::Size());
		}
		if (m_captureIndex==6)
		{
			m_minimapRenderer.mapView().close();
			for (const auto& reach : m_world.rivers().reaches)
			{
				if (reach.start.y>2 && reach.start.y<45 && reach.halfWidth>30)
				{ m_camera.setCaptureState((reach.start+reach.end)*.5,280,static_cast<float>(-40_deg),static_cast<float>(35_deg)); break; }
			}
		}
		if (m_captureIndex==7)
		{
			for (const auto& edge : m_trainNetwork.edges())
			{
				const Vec3 p=m_trainNetwork.getBezier(edge.id)->evaluate(.5f);const double gap=p.y-m_world.sampleHeight(static_cast<float>(p.x),static_cast<float>(p.z));
				if (gap>8 && gap<14) { m_camera.setCaptureState(p,18,static_cast<float>(-30_deg),static_cast<float>(-18_deg)); break; }
			}
		}
		if (m_captureIndex==8 || m_captureIndex==9)
		{
			const auto visit=[&](const CubicBezier& curve)
			{
				for (float arc=0;arc<curve.totalLength;arc+=4)
				{
					const Vec3 p=curve.positionAt(arc),tangent=curve.tangentAt(arc);const double depth=m_world.sampleHeight(static_cast<float>(p.x),static_cast<float>(p.z))-p.y;
					if (depth>2 && depth<5) { m_camera.setCaptureState(p+Vec3{0,2.4,0},18,static_cast<float>(Atan2(-tangent.x,-tangent.z)),0);return true; }
				}
				return false;
			};
			if (m_captureIndex==8) { for (const auto& edge : m_network.edges()) { if (edge.id>=0 && edge.tunnel && visit(*m_network.getBezier(edge.id))) { break; } } }
			else { for (const auto& edge : m_trainNetwork.edges()) { if (edge.id>=0 && visit(*m_trainNetwork.getBezier(edge.id))) { break; } } }
		}
		if (m_captureIndex==10)
		{
			m_minimapRenderer.openFullScreen(m_camera,m_network,m_trainNetwork,m_districts);auto& view=m_minimapRenderer.mapView();view.zoom=2;
			const Vec2 before=view.center;view.panKeyboard({1,-1},.1,Scene::Size());
			DBG_LOG(U"[MapKeyboardReview] movedPixels={:.2f} rivers={} boundaries={}"_fmt(view.center.distanceFrom(before)*view.scale(Scene::Size()),view.rivers.size(),view.boundaries.size()));
		}
		if (m_captureIndex>=11)
		{
			m_minimapRenderer.mapView().close();
			if (m_captureIndex==13)
			{
				for (const auto& edge : m_trainNetwork.edges())
				{
					if (edge.id<0) { continue; }const auto curve=m_trainNetwork.getBezier(edge.id);const Vec3 p=curve->evaluate(.5f),tangent=curve->tangent(.5f);
					if (m_world.sampleHeight(static_cast<float>(p.x),static_cast<float>(p.z))-p.y>10) { m_camera.setWalkingState(p+Vec3{0,.15,0},static_cast<float>(Atan2(tangent.x,tangent.z)));break; }
				}
			}
			else
			{
				for (const auto& edge : m_network.edges())
				{
					if (edge.id<0 || edge.tunnel || edge.length<45) { continue; }const auto curve=m_network.getBezier(edge.id);Vec3 p=curve->evaluate(.5f);const Vec3 tangent=curve->tangent(.5f),right=tangentToRight(tangent);
					const double ground=m_world.sampleHeight(static_cast<float>(p.x),static_cast<float>(p.z));const Vec3 side=p+right*(edge.totalWidth()*.5+28);
					const double relief=Abs(ground-m_world.sampleHeight(static_cast<float>(side.x),static_cast<float>(side.z)));
					if ((m_captureIndex==11 && !edge.useElevation && relief>5) || (m_captureIndex==12 && edge.useElevation && ground<m_world.waterSurfaceHeight(p.x,p.z)))
					{
						p.y=(edge.usesDesignHeight() ? p.y : ground)+kRoadSurfaceLift;m_camera.setWalkingState(p,static_cast<float>(Atan2(tangent.x,tangent.z)));break;
					}
				}
			}
			DBG_LOG(U"[WalkingTransportReview] view={} eye={}"_fmt(m_captureIndex,m_camera.eyePosition()));
		}
		m_captureCameraDirty=false; m_captureFrame=0;
	}
	m_world.update(m_camera.focusPoint()); const Stopwatch frameTimer{StartImmediately::Yes}; renderWorld();
	if (m_captureFrame==70 && m_worldRenderer.pendingTerrainJobs()>0 && !m_minimapRenderer.fullScreen()) { return; }
	if (++m_captureFrame==75)
	{
		ScreenCapture::SaveCurrentFrame(U"transport_{:02}.png"_fmt(m_captureIndex));
		DBG_LOG(U"[TransportReview] rendered={} map={} cpuDrawMs={:.2f}"_fmt(m_captureIndex,m_minimapRenderer.fullScreen(),frameTimer.msF()));
	}
	if (m_captureFrame>82)
	{
		if (++m_captureIndex==14)
		{
			auto& view=m_minimapRenderer.mapView();
			view.showContext(view.body(Scene::Size()).center(),Scene::Size());
			const auto target=view.jumpFromMenu(view.menuBounds().center());
			if (target) { jumpToMapPosition(*target); }
			const Vec3 focus=m_camera.focusPoint();
			const bool passed=target && Vec2{focus.x,focus.z}.distanceFrom(*target)<.01 && !view.visible;
			DBG_LOG(U"[TransportReview] mapJumpPassed={} streets={} labels={}"_fmt(passed,view.streets.size(),view.labels.size()));
			System::Exit(); return;
		}
		m_captureCameraDirty=true;
	}
}

void GameScene::updateStreetReview()
{
	constexpr int kViewCount = 6;
	constexpr int kWarmupFrames = 140;
	constexpr int kSampleFrames = 60;
	m_clock.speed = TimeSpeed::Paused;
	m_clock.hour = 13;
	if (m_streetReviewEdges.isEmpty())
	{
		HashTable<int, std::array<int, 3>> counts;
		for (int z = 0; z < WORLD_CHUNKS; ++z)
		{
			for (int x = 0; x < WORLD_CHUNKS; ++x)
			{
				const auto* chunk = m_world.getChunk({x, z});
				if (!chunk) { continue; }
				for (const auto& building : chunk->buildingGrid)
				{
					if (building.edgeId < 0) { continue; }
					auto& count = counts[building.edgeId];
					if (building.type == BuildingType::Shop || building.type == BuildingType::Office) { ++count[0]; }
					else if (building.type == BuildingType::Detached || building.type == BuildingType::LowApartment) { ++count[1]; }
				}
			}
		}
		for (int category = 0; category < 3; ++category)
		{
			double bestScore = -1;
			Optional<int> best;
			for (const auto& edge : m_network.edges())
			{
				if (edge.id < 0 || edge.useElevation || edge.length < 85 || edge.length > 600 || edge.totalWidth() > 18) { continue; }
				const auto iterator = counts.find(edge.id);
				if (iterator == counts.end()) { continue; }
				const Vec3 point = m_network.getBezier(edge.id)->evaluate(.5f);
				double villageDistance = Math::Inf;
				for (const auto& settlement : m_districts)
				{
					if (settlement.kind == MapGenerator::SettlementKind::RuralSettlement)
					{ villageDistance = Min(villageDistance, Vec2{point.x, point.z}.distanceFrom(settlement.center)); }
				}
				const auto& count = iterator->second;
				double score = category == 0 ? count[0] * 4.0 - count[1] : count[1] * 3.0 - count[0];
				if (category == 1 && villageDistance < 1600) { continue; }
				if (category == 2) { score = villageDistance < 500 ? count[1] * 2.0 + edge.length * .02 - villageDistance * .01 : -1; }
				if (score > bestScore) { bestScore = score; best = edge.id; }
			}
			if (!best) { DBG_LOG(U"[StreetReview] no candidate category={}"_fmt(category)); System::Exit(); return; }
			m_streetReviewEdges << *best;
		}
	}
	if (m_captureCameraDirty)
	{
		const auto* edge = m_network.getEdge(m_streetReviewEdges[m_captureIndex % 3]);
		const auto curve = m_network.getBezier(edge->id);
		const float arc = curve->totalLength * (m_captureIndex < 3 ? .25f : .75f);
		Vec3 point = curve->positionAt(arc);
		Vec3 direction = curve->tangentAt(arc) * (m_captureIndex < 3 ? 1 : -1);
		point += tangentToRight(direction) * (edge->totalWidth() * .30);
		point.y = m_world.sampleHeight(static_cast<float>(point.x), static_cast<float>(point.z));
		m_camera.setWalkingState(point, static_cast<float>(Atan2(direction.x, direction.z)));
		DBG_LOG(U"[StreetReviewCamera] view={} edge={} ground={} eye={} yaw={}"_fmt(m_captureIndex, edge->id, point, m_camera.eyePosition(), Atan2(direction.x, direction.z)));
		m_captureCameraDirty = false;
		m_captureFrame = 0;
		m_captureFrameTimes.clear();
		m_captureCpuTimes.clear();
	}
	m_world.update(m_camera.focusPoint());
	renderWorld();
	if (m_captureFrame == kWarmupFrames - kSampleFrames - 1 && m_worldRenderer.pendingTerrainJobs() > 0) { return; }
	if (m_captureFrame >= kWarmupFrames - kSampleFrames && m_captureFrame < kWarmupFrames)
	{
		m_captureFrameTimes << Scene::DeltaTime() * 1000;
		m_captureCpuTimes << m_renderTimings.total;
	}
	if (++m_captureFrame == kWarmupFrames)
	{
		ScreenCapture::SaveCurrentFrame(U"street_{:02}.png"_fmt(m_captureIndex));
		m_captureFrameTimes.sort(); m_captureCpuTimes.sort();
		DBG_LOG(U"[StreetReview] view={} frames={} frameP50={:.2f} frameP95={:.2f} cpuP50={:.2f} buildings={}"_fmt(m_captureIndex, m_captureFrameTimes.size(), m_captureFrameTimes[30], m_captureFrameTimes[56], m_captureCpuTimes[30], m_worldRenderer.buildingsSubmitted()));
	}
	if (m_captureFrame > kWarmupFrames + 8)
	{
		if (++m_captureIndex == kViewCount) { System::Exit(); return; }
		m_captureCameraDirty = true;
	}
}
